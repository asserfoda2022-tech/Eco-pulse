import 'package:flutter/material.dart';

class AppConstants {
  AppConstants._();

  static const String appName = 'ECO PULSE';
  static const int firstYear = 2001;
  static int get lastYear => DateTime.now().year; // تعديل

  /// Significance level used by scientists (95% confidence).
  static const double alpha = 0.05;

  /// Minimum number of annual values required to run the trend test.
  static const int minYears = 8;

  /// Minimum span (in years) between start and end of the analysis period.
  static const int minSpan = 9;
}

class ImpactRule {
  final String sectorEn;
  final String sectorAr;
  final String textEn;
  final String textAr;
  final IconData icon;

  const ImpactRule({
    required this.sectorEn,
    required this.sectorAr,
    required this.textEn,
    required this.textAr,
    required this.icon,
  });
}

/// Knowledge base: what a significant increase / decrease of a variable
/// typically affects. Written as general guidance for the Egyptian context.
class ImpactRules {
  ImpactRules._();

  static List<ImpactRule> forVariable(String id, bool increasing) {
    final key = '$id:${increasing ? 'up' : 'down'}';
    return _rules[key] ?? const <ImpactRule>[];
  }

  static const Map<String, List<ImpactRule>> _rules = {
    'temperature:up': [
      ImpactRule(
        sectorEn: 'Agriculture',
        sectorAr: 'الزراعة',
        textEn:
            'Higher heat raises crop water demand and can shorten the growing season of wheat, rice and cotton.',
        textAr:
            'ارتفاع الحرارة يزيد احتياج المحاصيل للمياه وقد يقصّر موسم نمو القمح والأرز والقطن.',
        icon: Icons.agriculture,
      ),
      ImpactRule(
        sectorEn: 'Energy & Health',
        sectorAr: 'الطاقة والصحة',
        textEn:
            'More electricity is needed for cooling and outdoor workers face greater heat stress.',
        textAr:
            'زيادة الأحمال الكهربائية للتبريد وإجهاد حراري أكبر للعاملين في الأماكن المفتوحة.',
        icon: Icons.bolt,
      ),
    ],
    'temperature:down': [
      ImpactRule(
        sectorEn: 'Agriculture',
        sectorAr: 'الزراعة',
        textEn:
            'Cooler conditions can delay ripening and lengthen the growing season of some crops.',
        textAr: 'الأجواء الأبرد قد تؤخر نضج المحاصيل وتطيل موسم نمو بعضها.',
        icon: Icons.agriculture,
      ),
      ImpactRule(
        sectorEn: 'Energy',
        sectorAr: 'الطاقة',
        textEn:
            'Cooling demand falls, while winter heating needs may slightly increase.',
        textAr: 'ينخفض الطلب على التبريد بينما قد تزيد احتياجات التدفئة شتاءً.',
        icon: Icons.bolt,
      ),
    ],
    'rainfall:up': [
      ImpactRule(
        sectorEn: 'Water & Flooding',
        sectorAr: 'المياه والسيول',
        textEn:
            'More rain raises flash-flood risk in wadis and strains city drainage, but can recharge groundwater.',
        textAr:
            'زيادة الأمطار ترفع خطر السيول في الأودية وتضغط على شبكات الصرف، لكنها تغذي المياه الجوفية.',
        icon: Icons.flood,
      ),
      ImpactRule(
        sectorEn: 'Agriculture',
        sectorAr: 'الزراعة',
        textEn:
            'Extra rainfall can reduce irrigation needs but intense storms may damage crops.',
        textAr:
            'الأمطار الإضافية تقلل الحاجة للري لكن العواصف الشديدة قد تضر بالمحاصيل.',
        icon: Icons.agriculture,
      ),
    ],
    'rainfall:down': [
      ImpactRule(
        sectorEn: 'Water Resources',
        sectorAr: 'الموارد المائية',
        textEn:
            'Less rain increases dependence on the Nile and groundwater and raises drought risk.',
        textAr:
            'قلة الأمطار تزيد الاعتماد على النيل والمياه الجوفية وترفع خطر الجفاف.',
        icon: Icons.water_drop,
      ),
      ImpactRule(
        sectorEn: 'Ecosystems & Livelihoods',
        sectorAr: 'البيئة وسبل العيش',
        textEn:
            'Dry spells stress grazing land and rain-fed farming, especially on the north-west coast.',
        textAr:
            'فترات الجفاف تضغط على المراعي والزراعة المطرية، خاصة في الساحل الشمالي الغربي.',
        icon: Icons.landscape,
      ),
    ],
    'soil:up': [
      ImpactRule(
        sectorEn: 'Agriculture',
        sectorAr: 'الزراعة',
        textEn:
            'Wetter root zones help crop establishment but may signal waterlogging or salinity risk, especially in the Delta.',
        textAr:
            'رطوبة أعلى في منطقة الجذور تساعد على إنبات المحاصيل لكنها قد تدل على تشبّع بالمياه أو مخاطر ملوحة خاصة في الدلتا.',
        icon: Icons.agriculture,
      ),
      ImpactRule(
        sectorEn: 'Water Management',
        sectorAr: 'إدارة المياه',
        textEn:
            'Higher soil water can reflect more irrigation or rainfall and raises drainage demand.',
        textAr:
            'ارتفاع مياه التربة قد يعكس زيادة الري أو الأمطار ويرفع الحاجة للصرف.',
        icon: Icons.water,
      ),
    ],
    'soil:down': [
      ImpactRule(
        sectorEn: 'Agriculture',
        sectorAr: 'الزراعة',
        textEn:
            'A drier root zone means crops need more irrigation and yields become more vulnerable.',
        textAr:
            'جفاف منطقة الجذور يعني حاجة أكبر للري وتعرّض أكبر للمحاصيل للخسارة.',
        icon: Icons.agriculture,
      ),
      ImpactRule(
        sectorEn: 'Land & Air Quality',
        sectorAr: 'الأرض وجودة الهواء',
        textEn: 'Drying soils increase land degradation and dust-storm risk.',
        textAr: 'جفاف التربة يزيد تدهور الأراضي وخطر العواصف الترابية.',
        icon: Icons.landscape,
      ),
    ],
    'humidity:up': [
      ImpactRule(
        sectorEn: 'Health & Comfort',
        sectorAr: 'الصحة والراحة',
        textEn:
            'Higher humidity makes heat feel more intense and can increase heat-related illness.',
        textAr:
            'ارتفاع الرطوبة يجعل الحرارة أشد إحساسًا وقد يزيد الأمراض المرتبطة بالحر.',
        icon: Icons.health_and_safety,
      ),
      ImpactRule(
        sectorEn: 'Infrastructure',
        sectorAr: 'البنية التحتية',
        textEn:
            'More humidity speeds up corrosion and mould in buildings and equipment.',
        textAr: 'زيادة الرطوبة تسرّع التآكل ونمو العفن في المباني والمعدات.',
        icon: Icons.apartment,
      ),
    ],
    'humidity:down': [
      ImpactRule(
        sectorEn: 'Health',
        sectorAr: 'الصحة',
        textEn: 'Drier air increases dust and respiratory irritation.',
        textAr: 'الهواء الأجف يزيد الغبار وتهيّج الجهاز التنفسي.',
        icon: Icons.health_and_safety,
      ),
      ImpactRule(
        sectorEn: 'Agriculture',
        sectorAr: 'الزراعة',
        textEn:
            'Faster evaporation raises water losses from irrigation canals and fields.',
        textAr: 'التبخر الأسرع يزيد فاقد المياه من قنوات الري والحقول.',
        icon: Icons.agriculture,
      ),
    ],
    'wind:up': [
      ImpactRule(
        sectorEn: 'Energy',
        sectorAr: 'الطاقة',
        textEn:
            'Stronger winds boost wind-power potential (Gulf of Suez, Red Sea) but also dust and erosion.',
        textAr:
            'الرياح الأقوى ترفع إمكانات طاقة الرياح (خليج السويس والبحر الأحمر) لكنها تزيد الغبار والتعرية.',
        icon: Icons.bolt,
      ),
      ImpactRule(
        sectorEn: 'Coasts & Transport',
        sectorAr: 'السواحل والنقل',
        textEn: 'Rougher conditions affect coastal shipping and sand movement.',
        textAr: 'الأجواء الأعنف تؤثر على الملاحة الساحلية وحركة الرمال.',
        icon: Icons.sailing,
      ),
    ],
    'wind:down': [
      ImpactRule(
        sectorEn: 'Energy',
        sectorAr: 'الطاقة',
        textEn: 'Lower wind speeds reduce the output of wind farms.',
        textAr: 'انخفاض سرعة الرياح يقلل إنتاج مزارع الرياح.',
        icon: Icons.bolt,
      ),
      ImpactRule(
        sectorEn: 'Air Quality',
        sectorAr: 'جودة الهواء',
        textEn: 'Weaker winds let pollution and heat linger over cities.',
        textAr: 'ضعف الرياح يجعل التلوث والحرارة يتراكمان فوق المدن.',
        icon: Icons.cloud,
      ),
    ],
  };
}
