import 'package:flutter/material.dart';
import 'package:project_1/models/investigation_model.dart';
import 'package:project_1/screens/home_screen.dart';
import 'package:project_1/screens/introduction_screen.dart';
import 'package:project_1/screens/investigation_datails_screen.dart';
import 'package:project_1/screens/login_screen.dart';
import 'package:project_1/screens/result_screen.dart';
import 'package:project_1/screens/setting_screen.dart';
import 'package:project_1/screens/splash_screen.dart';

class AppRoutes {
  AppRoutes._();

  static const String splash = '/';
  static const String introduction = '/introduction';
  static const String login = '/login';
  static const String home = '/home';
  static const String results = '/results';
  static const String details = '/details';
  static const String settings = '/settings';

  static Route<dynamic> generateRoute(RouteSettings settings) {
    Widget page;
    switch (settings.name) {
      case introduction:
        page = const IntroductionScreen();
        break;
      case login:
        page = const LoginScreen();
        break;
      case home:
        page = const HomeScreen();
        break;
      case results:
        page = ResultsScreen(
            investigation: settings.arguments as InvestigationModel);
        break;
      case details:
        page = InvestigationDetailsScreen(
            args: settings.arguments as InvestigationDetailsArgs);
        break;
      case AppRoutes.settings:
        page = const SettingScreen();
        break;
      case splash:
      default:
        page = const SplashScreen();
    }

    return PageRouteBuilder<dynamic>(
      settings: settings,
      pageBuilder: (_, __, ___) => page,
      transitionDuration: const Duration(milliseconds: 280),
      transitionsBuilder: (_, animation, __, child) =>
          FadeTransition(opacity: animation, child: child),
    );
  }
}
