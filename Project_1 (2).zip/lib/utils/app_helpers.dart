import 'package:flutter/material.dart';
import 'package:project_1/data/governorate_data.dart';
import 'package:project_1/models/investigation_model.dart';
import 'package:project_1/theme/app_colors.dart';
import 'package:project_1/theme/app_language.dart';

/// Tiny global state shared between tabs.
class AppState {
  AppState._();

  static final ValueNotifier<Governorate> selectedGovernorate =
      ValueNotifier<Governorate>(GovernorateData.defaultGovernorate);

  static final ValueNotifier<int> tabIndex = ValueNotifier<int>(0);
}

class AppHelpers {
  AppHelpers._();

  static String fmt(double v, int decimals) => v.toStringAsFixed(decimals);

  static String fmtSigned(double v, int decimals) {
    final s = v.toStringAsFixed(decimals);
    return v > 0 ? '+$s' : s;
  }

  static String fmtPercent(double p) {
    if (p.abs() > 999) return p > 0 ? '> +999%' : '< -999%';
    return '${fmtSigned(p, 1)}%';
  }

  static String fmtP(double p) => p < 0.001 ? '< 0.001' : p.toStringAsFixed(3);

  /// Decimals used for "change" numbers (one more than the value itself).
  static int changeDecimals(int valueDecimals) => valueDecimals + 1;

  static Color trendColor(TrendResult r) {
    if (!r.significant) return AppColors.stable;
    return r.direction == TrendDirection.increasing
        ? AppColors.rising
        : AppColors.falling;
  }

  static IconData trendIcon(TrendResult r) {
    switch (r.direction) {
      case TrendDirection.increasing:
        return Icons.trending_up_rounded;
      case TrendDirection.decreasing:
        return Icons.trending_down_rounded;
      case TrendDirection.stable:
        return Icons.trending_flat_rounded;
    }
  }

  /// e.g. "Significant increase" / "No significant trend".
  static String verdict(BuildContext context, TrendResult r) {
    if (!r.significant) {
      return context.tr('No significant trend', 'لا يوجد اتجاه معنوي');
    }
    return r.direction == TrendDirection.increasing
        ? context.tr('Significant increase', 'زيادة معنوية')
        : context.tr('Significant decrease', 'انخفاض معنوي');
  }

  static String directionWord(BuildContext context, TrendResult r) {
    switch (r.direction) {
      case TrendDirection.increasing:
        return context.tr('increasing', 'في ازدياد');
      case TrendDirection.decreasing:
        return context.tr('decreasing', 'في انخفاض');
      case TrendDirection.stable:
        return context.tr('stable', 'مستقر');
    }
  }

  static void snack(BuildContext context, String message) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }
}
