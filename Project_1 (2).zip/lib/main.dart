import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:project_1/theme/app_language.dart';
import 'package:project_1/theme/app_theme.dart';
import 'package:project_1/utils/app_constants.dart';
import 'package:project_1/utils/app_routes.dart';

const FirebaseOptions _webOptions = FirebaseOptions(
  apiKey: 'AIzaSyCEyaIMxaUgMUyHqwHEOPKvZ5xBIHvx4Gc',
  authDomain: 'eco-pulse-23735.firebaseapp.com',
  projectId: 'eco-pulse-23735',
  storageBucket: 'eco-pulse-23735.firebasestorage.app',
  messagingSenderId: '91395744192',
  appId: '1:91395744192:web:771b16a5dfa47ce465e825',
);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    if (kIsWeb) {
      await Firebase.initializeApp(options: _webOptions);
    } else {
      await Firebase.initializeApp();
    }
  } catch (e) {
    // The app still works without Firebase; only Community needs it.
    debugPrint('Firebase init failed: $e');
  }
  runApp(const EcoPulseApp());
}

class EcoPulseApp extends StatelessWidget {
  const EcoPulseApp({super.key});

  @override
  Widget build(BuildContext context) {
    return AppLanguageScope(
      notifier: AppLanguage.isArabic,
      child: ValueListenableBuilder<bool>(
        valueListenable: AppLanguage.isArabic,
        builder: (context, isArabic, _) {
          return MaterialApp(
            title: AppConstants.appName,
            debugShowCheckedModeBanner: false,
            theme: AppTheme.dark,
            themeMode: ThemeMode.dark,
            initialRoute: AppRoutes.splash,
            onGenerateRoute: AppRoutes.generateRoute,
            builder: (context, child) {
              return Directionality(
                textDirection: isArabic ? TextDirection.rtl : TextDirection.ltr,
                child: child ?? const SizedBox.shrink(),
              );
            },
          );
        },
      ),
    );
  }
}
