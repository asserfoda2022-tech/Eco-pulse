class Governorate {
  final String id;
  final String nameEn;
  final String nameAr;
  final double lat;
  final double lon;
  final String regionEn;
  final String regionAr;

  const Governorate(
    this.id,
    this.nameEn,
    this.nameAr,
    this.lat,
    this.lon,
    this.regionEn,
    this.regionAr,
  );

  String name(bool ar) => ar ? nameAr : nameEn;
  String region(bool ar) => ar ? regionAr : regionEn;

  // NASA POWER location
  String get nasaLocation => '$lat,$lon';

  // Geographic region identifier
  String get regionId {
    switch (regionEn) {
      case 'Nile Delta':
        return 'nile_delta';
      case 'Upper Egypt':
        return 'upper_egypt';
      case 'Middle Egypt':
        return 'middle_egypt';
      case 'Western Desert':
        return 'western_desert';
      case 'Mediterranean coast':
        return 'mediterranean';
      case 'Red Sea coast':
        return 'red_sea';
      case 'Sinai':
        return 'sinai';
      case 'Suez Canal':
        return 'suez_canal';
      case 'Greater Cairo':
        return 'greater_cairo';
      default:
        return 'other';
    }
  }
}

class GovernorateData {
  GovernorateData._();

  static const List<Governorate> all = [
    Governorate('cairo', 'Cairo', 'القاهرة', 30.04, 31.24, 'Greater Cairo',
        'القاهرة الكبرى'),
    Governorate('alexandria', 'Alexandria', 'الإسكندرية', 31.20, 29.92,
        'Mediterranean coast', 'ساحل البحر المتوسط'),
    Governorate('giza', 'Giza', 'الجيزة', 30.01, 31.21, 'Greater Cairo',
        'القاهرة الكبرى'),
    Governorate('dakahlia', 'Dakahlia', 'الدقهلية', 31.04, 31.38, 'Nile Delta',
        'دلتا النيل'),
    Governorate('red_sea', 'Red Sea', 'البحر الأحمر', 27.26, 33.81,
        'Red Sea coast', 'ساحل البحر الأحمر'),
    Governorate('beheira', 'Beheira', 'البحيرة', 31.03, 30.47, 'Nile Delta',
        'دلتا النيل'),
    Governorate('fayoum', 'Fayoum', 'الفيوم', 29.31, 30.84, 'Middle Egypt',
        'مصر الوسطى'),
    Governorate('gharbia', 'Gharbia', 'الغربية', 30.79, 31.00, 'Nile Delta',
        'دلتا النيل'),
    Governorate('ismailia', 'Ismailia', 'الإسماعيلية', 30.60, 32.27,
        'Suez Canal', 'قناة السويس'),
    Governorate('menoufia', 'Menoufia', 'المنوفية', 30.56, 31.01, 'Nile Delta',
        'دلتا النيل'),
    Governorate(
        'minya', 'Minya', 'المنيا', 28.11, 30.75, 'Middle Egypt', 'مصر الوسطى'),
    Governorate('qalyubia', 'Qalyubia', 'القليوبية', 30.47, 31.18,
        'Greater Cairo', 'القاهرة الكبرى'),
    Governorate('new_valley', 'New Valley', 'الوادي الجديد', 25.45, 30.55,
        'Western Desert', 'الصحراء الغربية'),
    Governorate(
        'suez', 'Suez', 'السويس', 29.97, 32.55, 'Suez Canal', 'قناة السويس'),
    Governorate(
        'aswan', 'Aswan', 'أسوان', 24.09, 32.90, 'Upper Egypt', 'صعيد مصر'),
    Governorate(
        'assiut', 'Assiut', 'أسيوط', 27.18, 31.18, 'Upper Egypt', 'صعيد مصر'),
    Governorate('beni_suef', 'Beni Suef', 'بني سويف', 29.07, 31.10,
        'Middle Egypt', 'مصر الوسطى'),
    Governorate('port_said', 'Port Said', 'بورسعيد', 31.27, 32.30, 'Suez Canal',
        'قناة السويس'),
    Governorate('damietta', 'Damietta', 'دمياط', 31.42, 31.81, 'Nile Delta',
        'دلتا النيل'),
    Governorate('sharkia', 'Sharkia', 'الشرقية', 30.59, 31.50, 'Nile Delta',
        'دلتا النيل'),
    Governorate('south_sinai', 'South Sinai', 'جنوب سيناء', 28.24, 33.62,
        'Sinai', 'سيناء'),
    Governorate('kafr_el_sheikh', 'Kafr El Sheikh', 'كفر الشيخ', 31.11, 30.94,
        'Nile Delta', 'دلتا النيل'),
    Governorate('matrouh', 'Matrouh', 'مطروح', 31.35, 27.24,
        'Mediterranean coast', 'ساحل البحر المتوسط'),
    Governorate(
        'luxor', 'Luxor', 'الأقصر', 25.70, 32.64, 'Upper Egypt', 'صعيد مصر'),
    Governorate('qena', 'Qena', 'قنا', 26.16, 32.72, 'Upper Egypt', 'صعيد مصر'),
    Governorate('north_sinai', 'North Sinai', 'شمال سيناء', 31.13, 33.80,
        'Sinai', 'سيناء'),
    Governorate(
        'sohag', 'Sohag', 'سوهاج', 26.56, 31.69, 'Upper Egypt', 'صعيد مصر'),
  ];

  static Governorate get defaultGovernorate => byId('luxor');

  static Governorate byId(String id) =>
      all.firstWhere((g) => g.id == id, orElse: () => all.first);

  static List<Governorate> byRegion(String regionId) =>
      all.where((g) => g.regionId == regionId).toList();
}
