class PhenomenonImpact {
  final String variableId;
  final String summaryEn;
  final String summaryAr;
  final List<String> impactsEn;
  final List<String> impactsAr;
  final String areasEn;
  final String areasAr;
  final List<String> exposedGovernorateIds;

  // NASA data information
  final String nasaSource;
  final String nasaParameter;
  final String unit;
  final String period;
  final String limitationAr;

  const PhenomenonImpact({
    required this.variableId,
    required this.summaryEn,
    required this.summaryAr,
    required this.impactsEn,
    required this.impactsAr,
    required this.areasEn,
    required this.areasAr,
    required this.nasaSource,
    required this.nasaParameter,
    required this.unit,
    this.period = '2000-2030 (Projected)',
    this.limitationAr = '',
    this.exposedGovernorateIds = const [],
  });

  String summary(bool ar) => ar ? summaryAr : summaryEn;
  List<String> impacts(bool ar) => ar ? impactsAr : impactsEn;
  String areas(bool ar) => ar ? areasAr : areasEn;
}

class PhenomenaImpactData {
  PhenomenaImpactData._();

  static const List<PhenomenonImpact> all = [
    // TEMPERATURE
    PhenomenonImpact(
        variableId: 'temperature',
        nasaSource: 'NASA POWER',
        nasaParameter: 'T2M',
        unit: '°C',
        period: '2000-2030 (Projected)',
        summaryEn:
            'Air temperature affects water demand, agriculture, energy consumption and human health. Historical NASA observations can reveal long-term warming patterns across Egypt.',
        summaryAr:
            'درجة حرارة الهواء بتأثر على احتياجات المياه والزراعة واستهلاك الكهرباء وصحة الإنسان. بيانات ناسا التاريخية بتساعدنا نحدد اتجاه تغير الحرارة في محافظات مصر.',
        impactsEn: [
          'Agriculture: high temperatures can increase crop heat stress.',
          'Water: higher temperatures can increase evaporative demand.',
          'Energy: hot weather increases cooling and electricity demand.',
          'Health: extreme heat increases heat-related health risks.',
          'Coasts: ocean warming is one factor contributing to sea-level rise.'
        ],
        impactsAr: [
          'الزراعة: الحرارة المرتفعة ممكن تزود الإجهاد الحراري للمحاصيل.',
          'المياه: ارتفاع الحرارة ممكن يزود معدل التبخر واحتياجات الري.',
          'الطاقة: الطقس الحار بيرفع استهلاك الكهرباء والتكييف.',
          'الصحة: موجات الحر بتزود مخاطر الإجهاد الحراري.',
          'السواحل: ارتفاع حرارة المحيطات عامل من عوامل ارتفاع مستوى البحر.'
        ],
        areasEn:
            'Compare Upper Egypt, Middle Egypt, the Nile Delta and Western Desert.',
        areasAr: 'قارن بين الصعيد ومصر الوسطى والدلتا والصحراء الغربية.',
        exposedGovernorateIds: [
          'aswan',
          'luxor',
          'qena',
          'sohag',
          'assiut',
          'minya',
          'new_valley',
          'fayoum',
          'cairo',
          'dakahlia',
          'matrouh'
        ],
        limitationAr:
            'T2M measures air temperature at approximately 2 meters, not land surface temperature.'),

    // RAINFALL
    PhenomenonImpact(
        variableId: 'rainfall',
        nasaSource: 'NASA POWER',
        nasaParameter: 'PRECTOTCORR',
        unit: 'mm/day',
        period: '2000-2030 (Projected)',
        summaryEn:
            'Rainfall is unevenly distributed across Egypt. Northern coastal areas receive more rain than most inland desert areas. Changes can affect agriculture, flash floods and groundwater recharge.',
        summaryAr:
            'الأمطار مش موزعة بالتساوي في مصر. الساحل الشمالي بيستقبل أمطار أكتر من معظم المناطق الصحراوية الداخلية. تغير الأمطار ممكن يأثر على الزراعة والسيول وتغذية المياه الجوفية.',
        impactsEn: [
          'Floods: intense rainfall can cause flash floods in mountain wadis.',
          'Agriculture: winter rainfall supports rain-fed farming in the northwest.',
          'Cities: heavy rainfall can overwhelm urban drainage.',
          'Groundwater: rainfall may recharge some desert aquifers locally.',
          'Water security: Egyptian Nile water availability also depends on rainfall outside Egypt.'
        ],
        impactsAr: [
          'السيول: الأمطار الشديدة ممكن تسبب سيول في الأودية الجبلية.',
          'الزراعة: أمطار الشتاء بتساعد الزراعة المطرية في شمال غرب مصر.',
          'المدن: الأمطار الغزيرة ممكن تضغط على شبكات الصرف.',
          'المياه الجوفية: بعض الأمطار ممكن تساهم في تغذية المياه الجوفية محلياً.',
          'أمن المياه: موارد النيل بتعتمد كمان على الأمطار خارج حدود مصر.'
        ],
        areasEn:
            'Compare Matrouh, Alexandria, North Sinai, South Sinai, Red Sea and Upper Egypt.',
        areasAr:
            'قارن مطروح والإسكندرية وشمال وجنوب سيناء والبحر الأحمر والصعيد.',
        exposedGovernorateIds: [
          'matrouh',
          'alexandria',
          'north_sinai',
          'south_sinai',
          'red_sea',
          'aswan',
          'qena'
        ],
        limitationAr:
            'NASA POWER precipitation is not a direct flood measurement. Use GPM IMERG for rainfall event analysis.'),

    // SOIL MOISTURE
    PhenomenonImpact(
        variableId: 'soil',
        nasaSource: 'NASA GLDAS',
        nasaParameter: 'SoilMoi0_10cm_inst',
        unit: 'kg/m²',
        period: '2000-2030 (Projected)',
        summaryEn:
            'Soil moisture describes water stored in the soil. It helps identify dry conditions and changes in land water availability.',
        summaryAr:
            'رطوبة التربة بتوضح كمية المياه المخزنة في التربة، وبتساعد في متابعة الجفاف وتغير توفر المياه للنباتات.',
        impactsEn: [
          'Agriculture: low soil moisture can increase crop water stress.',
          'Drought: persistent reductions can indicate drying conditions.',
          'Irrigation: measurements help assess irrigation demand.',
          'Land: soil moisture changes can influence land degradation.',
          'Monitoring: satellite-based estimates help track regional changes.'
        ],
        impactsAr: [
          'الزراعة: انخفاض رطوبة التربة ممكن يزود إجهاد المحاصيل.',
          'الجفاف: الانخفاض المستمر ممكن يكون مؤشر على جفاف المنطقة.',
          'الري: القياسات بتساعد في تقدير احتياجات الري.',
          'الأراضي: تغير رطوبة التربة ممكن يؤثر على تدهور الأراضي.',
          'المراقبة: بيانات الأقمار الصناعية بتساعد على متابعة التغيرات المكانية.'
        ],
        areasEn:
            'Compare the Nile Delta, Nile Valley, Fayoum and reclaimed desert areas.',
        areasAr:
            'قارن دلتا النيل ووادي النيل والفيوم والأراضي الصحراوية المستصلحة.',
        exposedGovernorateIds: [
          'dakahlia',
          'kafr_el_sheikh',
          'beheira',
          'damietta',
          'sharkia',
          'fayoum',
          'minya'
        ],
        limitationAr:
            'GLDAS soil moisture is a model-based estimate at coarse spatial resolution, not a field measurement of agricultural root-zone moisture.'),

    // HUMIDITY
    PhenomenonImpact(
        variableId: 'humidity',
        nasaSource: 'NASA POWER',
        nasaParameter: 'RH2M',
        unit: '%',
        period: '2000-2030 (Projected)',
        summaryEn:
            'Relative humidity describes how close the air is to saturation. It affects human comfort, evaporation and agricultural conditions.',
        summaryAr:
            'الرطوبة النسبية بتوضح مدى تشبع الهواء ببخار المياه، وبتأثر على الإحساس بالحرارة والتبخر والظروف الزراعية.',
        impactsEn: [
          'Health: humidity changes perceived heat and thermal comfort.',
          'Agriculture: humid conditions can support some crop diseases.',
          'Water: humidity affects atmospheric evaporative demand.',
          'Coasts: maritime air influences humidity in coastal cities.',
          'Buildings: persistent moisture can contribute to dampness and corrosion.'
        ],
        impactsAr: [
          'الصحة: الرطوبة بتغير الإحساس بالحرارة والراحة الحرارية.',
          'الزراعة: الرطوبة ممكن تساعد على انتشار بعض أمراض المحاصيل.',
          'المياه: الرطوبة بتأثر على الطلب التبخري للغلاف الجوي.',
          'السواحل: هواء البحر بيأثر على رطوبة المدن الساحلية.',
          'المباني: الرطوبة المستمرة ممكن تساهم في العفن والتآكل.'
        ],
        areasEn:
            'Compare Mediterranean coastal governorates with Upper Egypt and the Western Desert.',
        areasAr: 'قارن محافظات ساحل المتوسط بالصعيد والصحراء الغربية.',
        exposedGovernorateIds: [
          'alexandria',
          'matrouh',
          'damietta',
          'port_said',
          'dakahlia',
          'aswan',
          'new_valley'
        ],
        limitationAr:
            'RH2M is relative humidity at approximately 2 meters, not a direct measure of soil or crop moisture.'),

    // WIND
    PhenomenonImpact(
        variableId: 'wind',
        nasaSource: 'NASA POWER',
        nasaParameter: 'WS10M',
        unit: 'm/s',
        period: '2000-2030 (Projected)',
        summaryEn:
            'Wind speed affects dust transport, evaporation, coastal conditions and renewable energy potential.',
        summaryAr:
            'سرعة الرياح بتأثر على نقل الأتربة والتبخر والظروف الساحلية وإمكانيات إنتاج الطاقة المتجددة.',
        impactsEn: [
          'Dust: strong winds can transport dust and sand.',
          'Energy: wind resources support renewable electricity generation.',
          'Agriculture: wind can increase water loss from exposed crops.',
          'Transport: strong coastal winds can affect maritime operations.',
          'Environment: wind changes the movement and dispersion of airborne particles.'
        ],
        impactsAr: [
          'الأتربة: الرياح القوية ممكن تنقل الأتربة والرمال.',
          'الطاقة: الرياح بتوفر فرصة لإنتاج الكهرباء النظيفة.',
          'الزراعة: الرياح ممكن تزود فقد المياه من المحاصيل.',
          'النقل: الرياح الساحلية القوية ممكن تأثر على الملاحة.',
          'البيئة: اتجاه وسرعة الرياح بيأثروا على انتشار الملوثات.'
        ],
        areasEn:
            'Compare Red Sea, Suez, Sinai, Western Desert and Mediterranean coastal governorates.',
        areasAr:
            'قارن البحر الأحمر والسويس وسيناء والصحراء الغربية ومحافظات ساحل المتوسط.',
        exposedGovernorateIds: [
          'red_sea',
          'suez',
          'south_sinai',
          'north_sinai',
          'matrouh',
          'new_valley',
          'aswan'
        ],
        limitationAr:
            'WS10M is wind speed at 10 meters, not a direct measure of dust storms or wind energy production.'),

    // SOLAR RADIATION
    PhenomenonImpact(
        variableId: 'solar',
        nasaSource: 'NASA POWER',
        nasaParameter: 'ALLSKY_SFC_SW_DWN',
        unit: 'kWh/m²/day',
        period: '2000-2030 (Projected)',
        summaryEn:
            'Solar radiation measures incoming shortwave energy and helps assess solar energy potential and surface energy conditions.',
        summaryAr:
            'الإشعاع الشمسي بيقيس الطاقة الشمسية الواصلة لسطح الأرض، وبيساعد في تقييم فرص الطاقة الشمسية.',
        impactsEn: [
          'Energy: supports solar power potential assessment.',
          'Agriculture: available sunlight influences plant growth.',
          'Climate: solar energy influences surface heating.',
          'Water: solar radiation contributes to evaporation.',
          'Planning: geographic comparisons help identify suitable solar-energy locations.'
        ],
        impactsAr: [
          'الطاقة: بيساعد في تقييم إمكانيات الطاقة الشمسية.',
          'الزراعة: ضوء الشمس بيأثر على نمو النباتات.',
          'المناخ: الإشعاع الشمسي بيساهم في تسخين سطح الأرض.',
          'المياه: الطاقة الشمسية بتساهم في عملية التبخر.',
          'التخطيط: مقارنة المحافظات بتساعد في تحديد مواقع مناسبة للطاقة الشمسية.'
        ],
        areasEn:
            'Compare the Western Desert, New Valley, Aswan and other regions.',
        areasAr: 'قارن الصحراء الغربية والوادي الجديد وأسوان وباقي المناطق.',
        exposedGovernorateIds: [
          'new_valley',
          'aswan',
          'matrouh',
          'red_sea',
          'south_sinai'
        ],
        limitationAr:
            'Solar radiation is not the same as actual electricity generated by solar panels.'),
  ];

  static PhenomenonImpact? byVariableId(String id) {
    for (final p in all) {
      if (p.variableId == id) return p;
    }
    return null;
  }
}
