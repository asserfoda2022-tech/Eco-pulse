class ChatbotKnowledge {
  static const Map<String, String> answers = {
    'hello': 'Hello! Welcome to EcoPulse AI 🌍. '
        'How can I help you today?',
    'climate': 'Climate change refers to long-term changes '
        'in temperatures and weather patterns.',
    'temperature': 'Temperature is an important climate indicator. '
        'Studying its changes helps us understand '
        'long-term climate trends.',
    'rainfall': 'Rainfall is the amount of precipitation '
        'received in an area over a specific period.',
    'nasa': 'NASA provides Earth observation data that '
        'helps researchers study temperature, rainfall, '
        'vegetation, soil moisture and other variables.',
    'power': 'NASA POWER provides meteorological and solar '
        'data for scientific research and applications.',
    'water': 'Water conservation helps protect natural '
        'resources and supports environmental sustainability.',
    'luxor': 'Luxor is located in Upper Egypt. It has a '
        'hot desert climate with generally high temperatures.',
    'alexandria': 'Alexandria is a coastal city in northern Egypt. '
        'It has a Mediterranean climate.',
    'egypt': 'Egypt has different regional climate conditions. '
        'Northern coastal areas and southern regions '
        'can experience different weather patterns.',
    'vegetation': 'Vegetation cover refers to plants covering '
        'the land. It is an important environmental indicator.',
    'soil': 'Soil moisture describes the amount of water '
        'stored in the soil.',
    'evapotranspiration': 'Evapotranspiration combines evaporation '
        'and plant transpiration. It helps explain '
        'water loss in the environment.',
    'global warming': 'Global warming is the long-term increase '
        'in Earth average surface temperature.',
    'sustainability': 'Sustainability means using resources responsibly '
        'to protect the environment for future generations.',
    'help': 'You can ask me about:\n'
        '• Climate change\n'
        '• Temperature\n'
        '• Rainfall\n'
        '• NASA POWER\n'
        '• Water conservation\n'
        '• Vegetation cover\n'
        '• Soil moisture\n'
        '• Egyptian governorates',
  };

  static const String fallback =
      'I am EcoPulse AI 🌍. I can help you understand '
      'climate change, NASA data, temperature, rainfall, '
      'water resources and environmental topics.\n\n'
      'Try asking: What is climate change?';
}
