import 'package:flutter/material.dart';
import 'package:project_1/data/governorate_data.dart';
import 'package:project_1/models/earth_data_model.dart';
import 'package:project_1/models/investigation_model.dart';
import 'package:project_1/services/analysis_service.dart';
import 'package:project_1/services/nasa_api_service.dart';
import 'package:project_1/theme/app_colors.dart';
import 'package:project_1/theme/app_language.dart';
import 'package:project_1/theme/app_text_styles.dart';
import 'package:project_1/utils/app_helpers.dart';
import 'package:project_1/widgets/custom_app_bar.dart';
import 'package:project_1/widgets/custom_card.dart';
import 'package:project_1/widgets/egypt_map.dart';
import 'package:project_1/widgets/phenomenon_impact_section.dart';
import 'package:project_1/widgets/loading_widget.dart';
import 'package:project_1/widgets/phenomenon_card.dart';

/// Tab 3: compare ONE variable across all 27 governorates ("where is it changing?").
class ExploreScreen extends StatefulWidget {
  const ExploreScreen({super.key});

  @override
  State<ExploreScreen> createState() => _ExploreScreenState();
}

class _ExploreScreenState extends State<ExploreScreen> {
  EarthVariable _variable = EarthVariables.temperature;
  Map<String, GovernorateClimate> _climates = {};
  bool _loading = false;
  bool _loaded = false;
  int _done = 0;
  Governorate? _selected; // governorate tapped on the map

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _done = 0;
    });
    final res = await NasaApiService.fetchMany(
      GovernorateData.all,
      onProgress: (done, total) {
        if (mounted) setState(() => _done = done);
      },
    );
    if (!mounted) return;
    setState(() {
      _climates = res;
      _loading = false;
      _loaded = true;
    });
  }

  /// Trend of the selected variable for every governorate, strongest first.
  List<MapEntry<Governorate, TrendResult>> _ranked() {
    final out = <MapEntry<Governorate, TrendResult>>[];
    for (final g in GovernorateData.all) {
      final s = _climates[g.id]?.series[_variable.id];
      if (s == null || s.points.length < 8) continue;
      out.add(MapEntry(g, AnalysisService.analyzePoints(_variable, s.points)));
    }
    out.sort((a, b) => b.value.zScore.compareTo(a.value.zScore));
    return out;
  }

  @override
  Widget build(BuildContext context) {
    final ar = context.isAr;

    return ListView(
      padding: const EdgeInsets.only(bottom: 28),
      children: [
        CustomAppBar(
          title: context.tr('Explore', 'استكشاف'),
          subtitle: context.tr(
              'Where is it changing? Compare all 27 governorates',
              'أين يتغيّر؟ قارن بين المحافظات الـ٢٧'),
        ),
        SizedBox(
          height: 52,
          child: ListView.separated(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 0),
            scrollDirection: Axis.horizontal,
            itemCount: EarthVariables.all.length,
            separatorBuilder: (_, __) => const SizedBox(width: 8),
            itemBuilder: (context, i) {
              final v = EarthVariables.all[i];
              final on = v.id == _variable.id;
              return GestureDetector(
                onTap: () => setState(() => _variable = v),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  decoration: BoxDecoration(
                    color: on
                        ? AppColors.primary.withOpacity(0.18)
                        : AppColors.card,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                        color: on ? AppColors.primary : AppColors.cardBorder),
                  ),
                  child: Row(
                    children: [
                      Icon(v.icon,
                          size: 16,
                          color: on ? AppColors.primary : AppColors.textMuted),
                      const SizedBox(width: 6),
                      Text(
                        v.name(ar),
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color:
                              on ? AppColors.primary : AppColors.textSecondary,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 14),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: EgyptMap(
            governorates: GovernorateData.all,
            selected: _selected,
            colorOf: _markerColor,
            onSelected: (g) => setState(() => _selected = g),
          ),
        ),
        _mapLegend(context),
        if (_selected != null) _selectedCard(context, _selected!, ar),
        if (!_loaded && !_loading) ...[
          const SizedBox(height: 20),
          GlassCard(
            margin: const EdgeInsets.symmetric(horizontal: 20),
            padding: const EdgeInsets.all(20),
            onTap: _load,
            child: Column(
              children: [
                const Icon(Icons.travel_explore,
                    color: AppColors.primary, size: 40),
                const SizedBox(height: 12),
                Text(
                  context.tr('Load data for all governorates',
                      'تحميل بيانات كل المحافظات'),
                  style: AppTextStyles.h3,
                ),
                const SizedBox(height: 6),
                Text(
                  context.tr(
                      'Downloads NASA POWER data once (about 30-60 seconds), then switching variables is instant.',
                      'يحمّل بيانات NASA POWER مرة واحدة (حوالي ٣٠-٦٠ ثانية)، وبعدها التبديل بين المتغيرات فوري.'),
                  textAlign: TextAlign.center,
                  style: AppTextStyles.body,
                ),
              ],
            ),
          ),
        ],
        if (_loading)
          Padding(
            padding: const EdgeInsets.only(top: 60),
            child: LoadingWidget(
              progress: _done / GovernorateData.all.length,
              message: context.tr(
                  'Loading governorates... $_done / ${GovernorateData.all.length}',
                  'جارٍ تحميل المحافظات... $_done / ${GovernorateData.all.length}'),
            ),
          ),
        PhenomenonImpactSection(
          highlightId: _variable.id,
          selectedGovernorate: _selected,
        ),
        if (_loaded) ..._results(context, ar),
      ],
    );
  }

  /// Trend result of the selected variable for one governorate (or null).
  TrendResult? _trendOf(Governorate g) {
    final s = _climates[g.id]?.series[_variable.id];
    if (s == null || s.points.length < 8) return null;
    return AnalysisService.analyzePoints(_variable, s.points);
  }

  /// Marker colour: trend colour once data is loaded, brand green before.
  Color _markerColor(Governorate g) {
    if (!_loaded) return AppColors.primary;
    final r = _trendOf(g);
    return r == null ? AppColors.stable : AppHelpers.trendColor(r);
  }

  Widget _mapLegend(BuildContext context) {
    Widget item(Color c, String t) => Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
                width: 10,
                height: 10,
                decoration: BoxDecoration(color: c, shape: BoxShape.circle)),
            const SizedBox(width: 5),
            Text(t, style: AppTextStyles.caption),
          ],
        );

    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
      child: _loaded
          ? Wrap(
              spacing: 14,
              runSpacing: 6,
              children: [
                item(AppColors.rising, context.tr('Increasing', 'في زيادة')),
                item(AppColors.falling, context.tr('Decreasing', 'في انخفاض')),
                item(AppColors.stable, context.tr('No trend', 'بلا اتجاه')),
              ],
            )
          : Text(
              context.tr(
                  'Pinch or scroll to zoom. Tap a governorate. Load the data below to colour the map by trend.',
                  'قرّب بإصبعين أو بالسكرول. اضغط على أي محافظة. حمّل البيانات بالأسفل لتلوين الخريطة حسب الاتجاه.'),
              style: AppTextStyles.caption,
            ),
    );
  }

  Widget _selectedCard(BuildContext context, Governorate g, bool ar) {
    final r = _loaded ? _trendOf(g) : null;
    final cd = AppHelpers.changeDecimals(_variable.decimals);
    return GlassCard(
      margin: const EdgeInsets.fromLTRB(20, 12, 20, 0),
      padding: const EdgeInsets.all(14),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(g.name(ar), style: AppTextStyles.h3),
                Text(g.region(ar), style: AppTextStyles.caption),
                if (r != null) ...[
                  const SizedBox(height: 6),
                  Text(
                    '${_variable.name(ar)}: ${AppHelpers.fmtSigned(r.slopePerDecade, cd)} ${_variable.unit}/${context.tr('decade', 'عقد')}',
                    style: TextStyle(
                        color: AppHelpers.trendColor(r),
                        fontWeight: FontWeight.w700,
                        fontSize: 13),
                  ),
                ],
              ],
            ),
          ),
          TextButton.icon(
            onPressed: () {
              AppState.selectedGovernorate.value = g;
              AppState.tabIndex.value = 1;
            },
            icon: const Icon(Icons.analytics_outlined,
                size: 18, color: AppColors.primary),
            label: Text(
              context.tr('Analyze', 'تحليل'),
              style: const TextStyle(color: AppColors.primary),
            ),
          ),
        ],
      ),
    );
  }

  List<Widget> _results(BuildContext context, bool ar) {
    final ranked = _ranked();
    final anySample = _climates.values.any((c) => c.isSample);
    final up = ranked
        .where((e) => e.value.significant && e.value.slopePerYear > 0)
        .length;
    final down = ranked
        .where((e) => e.value.significant && e.value.slopePerYear < 0)
        .length;
    final none = ranked.length - up - down;
    final maxZ = ranked.fold<double>(
        1.0, (m, e) => e.value.zScore.abs() > m ? e.value.zScore.abs() : m);

    return [
      if (anySample)
        InfoBanner(
          icon: Icons.cloud_off_outlined,
          text: context.tr(
              'Some governorates use illustrative SAMPLE data because NASA could not be reached.',
              'بعض المحافظات تستخدم بيانات توضيحية تجريبية لتعذّر الوصول إلى ناسا.'),
        ),
      const SizedBox(height: 14),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Row(
          children: [
            _summary(Icons.trending_up_rounded, '$up',
                context.tr('Increasing', 'في زيادة'), AppColors.rising),
            const SizedBox(width: 10),
            _summary(Icons.trending_down_rounded, '$down',
                context.tr('Decreasing', 'في انخفاض'), AppColors.falling),
            const SizedBox(width: 10),
            _summary(Icons.trending_flat_rounded, '$none',
                context.tr('No trend', 'بلا اتجاه'), AppColors.stable),
          ],
        ),
      ),
      SectionTitle(
        context.tr('${_variable.name(false)} trend by governorate',
            'اتجاه ${_variable.nameAr} حسب المحافظة'),
        trailing: IconButton(
          onPressed: _load,
          icon: const Icon(Icons.refresh_rounded,
              color: AppColors.textSecondary, size: 20),
        ),
      ),
      for (final e in ranked) _row(context, e.key, e.value, maxZ, ar),
    ];
  }

  Widget _summary(IconData icon, String number, String label, Color color) {
    return Expanded(
      child: GlassCard(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
        child: Column(
          children: [
            Icon(icon, color: color),
            const SizedBox(height: 6),
            Text(number, style: AppTextStyles.value.copyWith(color: color)),
            Text(label, style: AppTextStyles.caption),
          ],
        ),
      ),
    );
  }

  Widget _row(BuildContext context, Governorate g, TrendResult r, double maxZ,
      bool ar) {
    final color = AppHelpers.trendColor(r);
    final cd = AppHelpers.changeDecimals(_variable.decimals);
    return GlassCard(
      margin: const EdgeInsets.fromLTRB(20, 0, 20, 8),
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      onTap: () {
        AppState.selectedGovernorate.value = g;
        AppState.tabIndex.value = 1;
      },
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(g.name(ar), style: AppTextStyles.h3),
                    Text(g.region(ar), style: AppTextStyles.caption),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    '${AppHelpers.fmtSigned(r.slopePerDecade, cd)} ${_variable.unit}/${context.tr('decade', 'عقد')}',
                    style: TextStyle(
                        color: color,
                        fontWeight: FontWeight.w700,
                        fontSize: 13),
                  ),
                  const SizedBox(height: 4),
                  SignificanceChip(significant: r.significant),
                ],
              ),
            ],
          ),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: (r.zScore.abs() / maxZ).clamp(0.02, 1.0),
              minHeight: 5,
              color: color,
              backgroundColor: AppColors.cardBorder,
            ),
          ),
        ],
      ),
    );
  }
}
