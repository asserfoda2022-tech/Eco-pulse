import 'package:flutter/material.dart';
import 'package:project_1/models/earth_data_model.dart';
import 'package:project_1/services/analysis_service.dart';
import 'package:project_1/theme/app_colors.dart';
import 'package:project_1/theme/app_language.dart';
import 'package:project_1/theme/app_text_styles.dart';
import 'package:project_1/utils/app_constants.dart';
import 'package:project_1/utils/app_helpers.dart';
import 'package:project_1/utils/app_routes.dart';
import 'package:project_1/widgets/custom_app_bar.dart';
import 'package:project_1/widgets/custom_button.dart';
import 'package:project_1/widgets/custom_card.dart';
import 'package:project_1/widgets/loading_widget.dart';
import 'package:project_1/widgets/location_selector.dart';

/// Tab 2: choose governorate + variables + period, then run the analysis.
class AnalyzeScreen extends StatefulWidget {
  const AnalyzeScreen({super.key});

  @override
  State<AnalyzeScreen> createState() => _AnalyzeScreenState();
}

class _AnalyzeScreenState extends State<AnalyzeScreen> {
  final Set<String> _selected = EarthVariables.all.map((v) => v.id).toSet();
  late RangeValues _range;
  bool _running = false;

  @override
  void initState() {
    super.initState();
    _range = RangeValues(
      AppConstants.firstYear.toDouble(),
      AppConstants.lastYear.toDouble(),
    );
    AppState.selectedGovernorate.addListener(_refresh);
  }

  @override
  void dispose() {
    AppState.selectedGovernorate.removeListener(_refresh);
    super.dispose();
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  Future<void> _run() async {
    if (_selected.isEmpty) {
      AppHelpers.snack(
        context,
        context.tr(
            'Select at least one variable.', 'اختر متغيرًا واحدًا على الأقل.'),
      );
      return;
    }
    setState(() => _running = true);
    try {
      final inv = await AnalysisService.runInvestigation(
        governorate: AppState.selectedGovernorate.value,
        variables:
            EarthVariables.all.where((v) => _selected.contains(v.id)).toList(),
        startYear: _range.start.round(),
        endYear: _range.end.round(),
      );
      if (!mounted) return;
      setState(() => _running = false);
      Navigator.pushNamed(context, AppRoutes.results, arguments: inv);
    } catch (e) {
      if (!mounted) return;
      setState(() => _running = false);
      AppHelpers.snack(
        context,
        context.tr('Something went wrong. Please try again.',
            'حدث خطأ ما. حاول مرة أخرى.'),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final ar = context.isAr;
    final gov = AppState.selectedGovernorate.value;

    return Stack(
      children: [
        ListView(
          padding: const EdgeInsets.only(bottom: 28),
          children: [
            CustomAppBar(
              title: context.tr('Analyze', 'تحليل'),
              subtitle: context.tr(
                  'Build your own investigation', 'ابنِ تحقيقك الخاص'),
            ),
            SectionTitle(context.tr('1. Where?', '١. أين؟')),
            LocationSelector(
              selected: gov,
              onChanged: (g) => AppState.selectedGovernorate.value = g,
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 8, 24, 0),
              child: Text(
                gov.region(ar),
                style: AppTextStyles.caption,
              ),
            ),
            SectionTitle(
              context.tr('2. What to measure?', '٢. ماذا نقيس؟'),
              trailing: TextButton(
                onPressed: () => setState(() {
                  if (_selected.length == EarthVariables.all.length) {
                    _selected.clear();
                  } else {
                    _selected.addAll(EarthVariables.all.map((v) => v.id));
                  }
                }),
                child: Text(
                  _selected.length == EarthVariables.all.length
                      ? context.tr('Clear', 'مسح')
                      : context.tr('Select all', 'تحديد الكل'),
                  style: const TextStyle(color: AppColors.primary),
                ),
              ),
            ),
            for (final v in EarthVariables.all) _variableRow(context, v, ar),
            SectionTitle(context.tr('3. Which years?', '٣. أي سنوات؟')),
            GlassCard(
              margin: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('${_range.start.round()}',
                          style: AppTextStyles.h2
                              .copyWith(color: AppColors.primary)),
                      Text(
                        '${(_range.end - _range.start).round() + 1} ${context.tr('years', 'سنة')}',
                        style: AppTextStyles.caption,
                      ),
                      Text('${_range.end.round()}',
                          style: AppTextStyles.h2
                              .copyWith(color: AppColors.primary)),
                    ],
                  ),
                  SliderTheme(
                    data: SliderTheme.of(context).copyWith(
                      activeTrackColor: AppColors.primary,
                      inactiveTrackColor: AppColors.cardBorder,
                      thumbColor: AppColors.primary,
                      overlayColor: AppColors.primary.withOpacity(0.15),
                      rangeThumbShape: const RoundRangeSliderThumbShape(
                          enabledThumbRadius: 9),
                    ),
                    child: RangeSlider(
                      values: _range,
                      min: AppConstants.firstYear.toDouble(),
                      max: AppConstants.lastYear.toDouble(),
                      divisions: AppConstants.lastYear - AppConstants.firstYear,
                      onChanged: (r) {
                        if (r.end - r.start >= AppConstants.minSpan) {
                          setState(() => _range = r);
                        }
                      },
                    ),
                  ),
                  Text(
                    context.tr(
                        'At least ${AppConstants.minSpan + 1} years are needed for a reliable trend.',
                        'نحتاج ${AppConstants.minSpan + 1} سنوات على الأقل لاتجاه موثوق.'),
                    style: AppTextStyles.caption,
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
            InfoBanner(
              icon: Icons.science_outlined,
              color: AppColors.primary,
              text: context.tr(
                  'Method: annual means from NASA POWER, Mann-Kendall trend test and Sen\'s slope. A change is called "significant" when p < ${AppConstants.alpha}.',
                  'الطريقة: متوسطات سنوية من NASA POWER، واختبار مان-كندال لتحديد الاتجاه وميل سين. يُعتبر التغيّر «معنويًا» عندما تكون p < ${AppConstants.alpha}.'),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
              child: CustomButton(
                label: context.tr('Run analysis', 'ابدأ التحليل'),
                icon: Icons.analytics_outlined,
                onPressed: _running ? null : _run,
              ),
            ),
          ],
        ),
        if (_running)
          Positioned.fill(
            child: LoadingOverlay(
              message: context.tr('Reading NASA data for ${gov.nameEn}...',
                  'جارٍ قراءة بيانات ناسا لمحافظة ${gov.nameAr}...'),
            ),
          ),
      ],
    );
  }

  Widget _variableRow(BuildContext context, EarthVariable v, bool ar) {
    final on = _selected.contains(v.id);
    return GlassCard(
      margin: const EdgeInsets.fromLTRB(20, 0, 20, 10),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      color: on ? AppColors.primary.withOpacity(0.12) : null,
      onTap: () => setState(() {
        if (on) {
          _selected.remove(v.id);
        } else {
          _selected.add(v.id);
        }
      }),
      child: Row(
        children: [
          Icon(v.icon, color: on ? AppColors.primary : AppColors.textMuted),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(v.name(ar), style: AppTextStyles.h3),
                Text(v.description(ar),
                    style: AppTextStyles.caption,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis),
              ],
            ),
          ),
          Icon(
            on ? Icons.check_circle_rounded : Icons.circle_outlined,
            color: on ? AppColors.primary : AppColors.textMuted,
          ),
        ],
      ),
    );
  }
}
