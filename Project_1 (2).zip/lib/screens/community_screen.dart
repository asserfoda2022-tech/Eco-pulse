import 'package:flutter/material.dart';
import 'package:project_1/models/community_post.dart';
import 'package:project_1/screens/add_post_screen.dart';
import 'package:project_1/services/community_service.dart';
import 'package:project_1/widgets/post_card.dart';
import 'package:project_1/data/governorate_data.dart';
import 'package:project_1/theme/app_colors.dart';
import 'package:project_1/theme/app_language.dart';
import 'package:project_1/theme/app_text_styles.dart';
import 'package:project_1/widgets/custom_app_bar.dart';
import 'package:project_1/widgets/custom_card.dart';

/// EcoPulse Community: environmental observations shared by users.
class CommunityScreen extends StatefulWidget {
  const CommunityScreen({super.key});

  @override
  State<CommunityScreen> createState() => _CommunityScreenState();
}

class _CommunityScreenState extends State<CommunityScreen> {
  /// null = all governorates
  String? _filterId;
  late final Stream<List<CommunityPost>> _stream;

  @override
  void initState() {
    super.initState();
    _stream = CommunityService.instance.postsStream();
  }

  @override
  Widget build(BuildContext context) {
    final isAr = context.isAr;
    return Scaffold(
      body: AppBackground(
        child: SafeArea(
          child: Column(
            children: [
              CustomAppBar(
                title: 'EcoPulse Community',
                subtitle: context.tr(
                  'Environmental observations across Egypt',
                  'ملاحظات بيئية من محافظات مصر',
                ),
                showBack: true,
              ),
              _FilterBar(
                value: _filterId,
                isAr: isAr,
                onChanged: (v) => setState(() => _filterId = v),
              ),
              const SizedBox(height: 12),
              Expanded(
                child: StreamBuilder<List<CommunityPost>>(
                  stream: _stream,
                  builder: (context, snap) {
                    if (snap.hasError) {
                      return _Message(
                        icon: Icons.cloud_off_rounded,
                        text: context.tr(
                          'Could not load posts. Check your connection and Firebase setup.',
                          'تعذّر تحميل المنشورات. تأكد من الاتصال وإعداد Firebase.',
                        ),
                      );
                    }
                    if (!snap.hasData) {
                      return const Center(
                        child:
                            CircularProgressIndicator(color: AppColors.primary),
                      );
                    }
                    final posts = snap.data!
                        .where((p) =>
                            _filterId == null || p.governorateId == _filterId)
                        .toList();
                    if (posts.isEmpty) {
                      return _Message(
                        icon: Icons.forum_outlined,
                        text: context.tr(
                          'No posts yet. Be the first to share an observation!',
                          'لا توجد منشورات بعد. كن أول من يشارك ملاحظة!',
                        ),
                      );
                    }
                    return ListView.builder(
                      padding: const EdgeInsets.only(bottom: 100),
                      itemCount: posts.length,
                      itemBuilder: (_, i) => PostCard(post: posts[i]),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: AppColors.primary,
        foregroundColor: AppColors.onPrimary,
        icon: const Icon(Icons.add_rounded),
        label: Text(context.tr('New post', 'منشور جديد')),
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const AddPostScreen()),
        ),
      ),
    );
  }
}

class _FilterBar extends StatelessWidget {
  final String? value;
  final bool isAr;
  final ValueChanged<String?> onChanged;
  const _FilterBar(
      {required this.value, required this.isAr, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.symmetric(horizontal: 16),
      height: 52,
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: Row(
        children: [
          const Icon(Icons.filter_list_rounded,
              color: AppColors.primary, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String?>(
                value: value,
                isExpanded: true,
                dropdownColor: const Color(0xFF14382D),
                borderRadius: BorderRadius.circular(16),
                menuMaxHeight: 380,
                icon: const Icon(Icons.keyboard_arrow_down_rounded,
                    color: AppColors.textSecondary),
                style: AppTextStyles.h3,
                items: [
                  DropdownMenuItem<String?>(
                    value: null,
                    child: Text(context.tr('All governorates', 'كل المحافظات')),
                  ),
                  for (final g in GovernorateData.all)
                    DropdownMenuItem<String?>(
                      value: g.id,
                      child: Text(g.name(isAr)),
                    ),
                ],
                onChanged: onChanged,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Message extends StatelessWidget {
  final IconData icon;
  final String text;
  const _Message({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 48, color: AppColors.textMuted),
            const SizedBox(height: 12),
            Text(text, textAlign: TextAlign.center, style: AppTextStyles.body),
          ],
        ),
      ),
    );
  }
}
