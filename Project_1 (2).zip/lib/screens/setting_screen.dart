import 'package:flutter/material.dart';
import 'package:project_1/services/analysis_service.dart';
import 'package:project_1/services/auth_service.dart';
import 'package:project_1/theme/app_colors.dart';
import 'package:project_1/theme/app_language.dart';
import 'package:project_1/theme/app_text_styles.dart';
import 'package:project_1/utils/app_helpers.dart';
import 'package:project_1/utils/app_routes.dart';
import 'package:project_1/widgets/custom_app_bar.dart';
import 'package:project_1/widgets/custom_card.dart';

class SettingScreen extends StatelessWidget {
  const SettingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final ar = context.isAr;
    return Scaffold(
      body: AppBackground(
        child: SafeArea(
          child: Column(
            children: [
              CustomAppBar(
                title: context.tr('Settings', 'الإعدادات'),
                showBack: true,
              ),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.only(top: 8, bottom: 28),
                  children: [
                    GlassCard(
                      margin: const EdgeInsets.symmetric(horizontal: 20),
                      child: Row(
                        children: [
                          const Icon(Icons.language, color: AppColors.primary),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                                context.tr('Arabic language', 'اللغة العربية'),
                                style: AppTextStyles.h3),
                          ),
                          Switch(
                            value: ar,
                            activeColor: AppColors.primary,
                            onChanged: AppLanguage.setArabic,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 10),
                    _tile(
                      context,
                      icon: Icons.delete_outline_rounded,
                      title: context.tr(
                          'Clear investigation history', 'مسح سجل التحقيقات'),
                      onTap: () {
                        AnalysisService.history.clear();
                        AppHelpers.snack(context,
                            context.tr('History cleared', 'تم مسح السجل'));
                      },
                    ),
                    _tile(
                      context,
                      icon: Icons.logout_rounded,
                      title: context.tr('Log out', 'تسجيل الخروج'),
                      onTap: () {
                        AuthService.instance.logout();
                        Navigator.pushNamedAndRemoveUntil(
                            context, AppRoutes.login, (route) => false);
                      },
                    ),
                    const SizedBox(height: 16),
                    InfoBanner(
                      icon: Icons.cloud_outlined,
                      color: AppColors.primary,
                      text: context.tr(
                          'Data source: NASA POWER (power.larc.nasa.gov). Open data, no API key required.',
                          'مصدر البيانات: NASA POWER (power.larc.nasa.gov). بيانات مفتوحة ولا تحتاج مفتاح API.'),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _tile(BuildContext context,
      {required IconData icon,
      required String title,
      required VoidCallback onTap}) {
    return GlassCard(
      margin: const EdgeInsets.fromLTRB(20, 0, 20, 10),
      onTap: onTap,
      child: Row(
        children: [
          Icon(icon, color: AppColors.textSecondary),
          const SizedBox(width: 12),
          Expanded(child: Text(title, style: AppTextStyles.h3)),
          const Icon(Icons.chevron_right_rounded, color: AppColors.textMuted),
        ],
      ),
    );
  }
}
