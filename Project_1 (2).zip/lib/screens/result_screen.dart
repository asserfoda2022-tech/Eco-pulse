import 'package:flutter/material.dart';
import 'package:project_1/models/earth_data_model.dart';
import 'package:project_1/models/investigation_model.dart';
import 'package:project_1/screens/investigation_datails_screen.dart';
import 'package:project_1/theme/app_colors.dart';
import 'package:project_1/theme/app_language.dart';
import 'package:project_1/theme/app_text_styles.dart';
import 'package:project_1/utils/app_constants.dart';
import 'package:project_1/utils/app_routes.dart';
import 'package:project_1/widgets/custom_app_bar.dart';
import 'package:project_1/widgets/custom_card.dart';
import 'package:project_1/widgets/phenomenon_card.dart';

/// Overview of one investigation: what changed, how much, and what it affects.
class ResultsScreen extends StatelessWidget {
  final InvestigationModel investigation;
  const ResultsScreen({super.key, required this.investigation});

  @override
  Widget build(BuildContext context) {
    final ar = context.isAr;
    final inv = investigation;
    final sig = inv.significantResults;

    return Scaffold(
      body: AppBackground(
        child: SafeArea(
          child: Column(
            children: [
              CustomAppBar(
                title: inv.governorate.name(ar),
                subtitle:
                    '${inv.governorate.region(ar)} · ${inv.startYear}-${inv.endYear}',
                showBack: true,
              ),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.only(bottom: 28),
                  children: [
                    if (inv.isSample)
                      InfoBanner(
                        icon: Icons.cloud_off_outlined,
                        text: context.tr(
                            'NASA servers could not be reached, so these results use illustrative SAMPLE data. Reconnect and run the analysis again for real values.',
                            'تعذّر الوصول إلى خوادم ناسا، لذلك تعتمد هذه النتائج على بيانات توضيحية تجريبية. أعد الاتصال وكرّر التحليل للحصول على القيم الحقيقية.'),
                      ),
                    const SizedBox(height: 12),
                    GlassCard(
                      margin: const EdgeInsets.symmetric(horizontal: 20),
                      padding: const EdgeInsets.all(20),
                      radius: 24,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            inv.results.isEmpty
                                ? context.tr('No data', 'لا توجد بيانات')
                                : '${sig.length} / ${inv.results.length}',
                            style: AppTextStyles.h1.copyWith(
                                color: AppColors.primary, fontSize: 34),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            inv.results.isEmpty
                                ? context.tr(
                                    'Not enough yearly data for the chosen period.',
                                    'لا توجد بيانات سنوية كافية للفترة المختارة.')
                                : context.tr(
                                    'variables show a statistically significant change (p < ${AppConstants.alpha}).',
                                    'متغيرات تُظهر تغيّرًا معنويًا إحصائيًا (p < ${AppConstants.alpha}).'),
                            style: AppTextStyles.body,
                          ),
                        ],
                      ),
                    ),
                    SectionTitle(context.tr('What is changing, and how much',
                        'ما الذي يتغيّر وبكم')),
                    for (final r in inv.results)
                      TrendTile(
                        result: r,
                        onTap: () => Navigator.pushNamed(
                          context,
                          AppRoutes.details,
                          arguments: InvestigationDetailsArgs(inv, r),
                        ),
                      ),
                    SectionTitle(context.tr(
                        'What it affects', 'ما الذي يتأثر بهذا التغيّر')),
                    if (inv.impacts.isEmpty)
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: Text(
                          context.tr(
                              'No statistically significant change was found, so no impacts are flagged. Natural year-to-year variability may explain what you see.',
                              'لم يُعثر على تغيّر معنوي إحصائيًا، لذلك لا توجد تأثيرات مُشار إليها. قد يفسّر التباين الطبيعي بين السنوات ما تراه.'),
                          style: AppTextStyles.body,
                        ),
                      )
                    else
                      for (final n in inv.impacts) _ImpactCard(note: n),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Card describing one impact. Shared with the details screen.
class _ImpactCard extends StatelessWidget {
  final ImpactNote note;
  const _ImpactCard({required this.note});

  @override
  Widget build(BuildContext context) {
    final ar = context.isAr;
    return GlassCard(
      margin: const EdgeInsets.fromLTRB(20, 0, 20, 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.14),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(note.icon, color: AppColors.primary, size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(note.sector(ar), style: AppTextStyles.h3),
                const SizedBox(height: 4),
                Text(note.text(ar), style: AppTextStyles.body),
                const SizedBox(height: 6),
                Text(
                  '${note.increasing ? '↑' : '↓'} ${EarthVariables.byId(note.variableId).name(ar)}',
                  style: AppTextStyles.caption,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
