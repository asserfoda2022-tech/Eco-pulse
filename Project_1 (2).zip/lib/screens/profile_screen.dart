import 'package:flutter/material.dart';
import 'package:project_1/services/analysis_service.dart';
import 'package:project_1/services/auth_service.dart';
import 'package:project_1/theme/app_colors.dart';
import 'package:project_1/theme/app_language.dart';
import 'package:project_1/theme/app_text_styles.dart';
import 'package:project_1/utils/app_helpers.dart';
import 'package:project_1/utils/app_routes.dart';
import 'package:project_1/widgets/custom_app_bar.dart';
import 'package:project_1/widgets/custom_button.dart';
import 'package:project_1/widgets/custom_card.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  @override
  void initState() {
    super.initState();
    AuthService.instance.addListener(_refresh);
    AppState.tabIndex.addListener(_refresh);
  }

  @override
  void dispose() {
    AuthService.instance.removeListener(_refresh);
    AppState.tabIndex.removeListener(_refresh);
    super.dispose();
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final user = AuthService.instance.user;
    final history = AnalysisService.history;
    final isGuest = user == null || user.isGuest;
    final ar = context.isAr;

    return ListView(
      padding: const EdgeInsets.only(bottom: 28),
      children: [
        CustomAppBar(
          title: context.tr('Profile', 'حسابي'),
          subtitle: context.tr('Your investigations', 'تحقيقاتك'),
          trailing: AppIconButton(
            icon: Icons.settings_outlined,
            onTap: () => Navigator.pushNamed(context, AppRoutes.settings),
          ),
        ),
        const SizedBox(height: 8),
        GlassCard(
          margin: const EdgeInsets.symmetric(horizontal: 20),
          padding: const EdgeInsets.all(20),
          radius: 24,
          child: Row(
            children: [
              CircleAvatar(
                radius: 30,
                backgroundColor: AppColors.primary.withOpacity(0.2),
                child: isGuest
                    ? const Icon(Icons.person_outline,
                        color: AppColors.primary, size: 30)
                    : Text(
                        user?.initials ?? '?',
                        style: const TextStyle(
                            color: AppColors.primary,
                            fontSize: 20,
                            fontWeight: FontWeight.w800),
                      ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      isGuest
                          ? context.tr('Guest explorer', 'مستكشف زائر')
                          : (user?.name ?? ''),
                      style: AppTextStyles.h2,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      isGuest
                          ? context.tr('Sign up to keep your identity',
                              'سجّل حسابًا للاحتفاظ بهويتك')
                          : (user?.email ?? ''),
                      style: AppTextStyles.caption,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Row(
            children: [
              _stat(
                  '${history.length}', context.tr('Investigations', 'تحقيقات')),
              const SizedBox(width: 12),
              _stat(
                '${history.fold<int>(0, (a, i) => a + i.significantResults.length)}',
                context.tr('Significant trends', 'اتجاهات معنوية'),
              ),
            ],
          ),
        ),
        SectionTitle(context.tr('History', 'السجل')),
        if (history.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Text(
              context.tr(
                  'No investigations yet. Open the Analyze tab to start one.',
                  'لا توجد تحقيقات بعد. افتح تبويب «تحليل» لتبدأ.'),
              style: AppTextStyles.body,
            ),
          )
        else
          for (final inv in history)
            GlassCard(
              margin: const EdgeInsets.fromLTRB(20, 0, 20, 10),
              onTap: () => Navigator.pushNamed(context, AppRoutes.results,
                  arguments: inv),
              child: Row(
                children: [
                  const Icon(Icons.history_rounded, color: AppColors.primary),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(inv.governorate.name(ar), style: AppTextStyles.h3),
                        Text(
                          '${inv.startYear}-${inv.endYear} · '
                          '${inv.significantResults.length}/${inv.results.length} '
                          '${context.tr('significant', 'معنوية')}',
                          style: AppTextStyles.caption,
                        ),
                      ],
                    ),
                  ),
                  const Icon(Icons.chevron_right_rounded,
                      color: AppColors.textMuted),
                ],
              ),
            ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
          child: CustomButton(
            label: context.tr('Log out', 'تسجيل الخروج'),
            icon: Icons.logout_rounded,
            outlined: true,
            onPressed: () {
              AuthService.instance.logout();
              Navigator.pushNamedAndRemoveUntil(
                  context, AppRoutes.login, (route) => false);
            },
          ),
        ),
      ],
    );
  }

  Widget _stat(String number, String label) {
    return Expanded(
      child: GlassCard(
        padding: const EdgeInsets.symmetric(vertical: 16),
        child: Column(
          children: [
            Text(number,
                style: AppTextStyles.value.copyWith(color: AppColors.primary)),
            const SizedBox(height: 2),
            Text(label,
                style: AppTextStyles.caption, textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}
