import 'package:flutter/material.dart';
import 'package:project_1/theme/app_colors.dart';
import 'package:project_1/theme/app_language.dart';
import 'package:project_1/theme/app_text_styles.dart';
import 'package:project_1/utils/app_constants.dart';
import 'package:project_1/utils/app_routes.dart';
import 'package:project_1/widgets/custom_card.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _fade;
  late final Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..forward();
    _fade = CurvedAnimation(parent: _controller, curve: Curves.easeOut);
    _scale = Tween<double>(begin: 0.85, end: 1).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOutBack),
    );

    Future<void>.delayed(const Duration(milliseconds: 2400), () {
      if (!mounted) return;
      Navigator.pushReplacementNamed(context, AppRoutes.introduction);
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AppBackground(
        child: Center(
          child: FadeTransition(
            opacity: _fade,
            child: ScaleTransition(
              scale: _scale,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 96,
                    height: 96,
                    decoration: BoxDecoration(
                      color: AppColors.card,
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(color: AppColors.cardBorder),
                    ),
                    child: const Icon(Icons.eco_rounded,
                        color: AppColors.primary, size: 52),
                  ),
                  const SizedBox(height: 22),
                  Text(
                    AppConstants.appName,
                    style: AppTextStyles.h1.copyWith(letterSpacing: 3),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    context.tr('Closer to nature, climate-aware',
                        'أقرب للطبيعة، واعٍ بالمناخ'),
                    style: AppTextStyles.body,
                  ),
                  const SizedBox(height: 40),
                  const SizedBox(
                    width: 26,
                    height: 26,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.5,
                      color: AppColors.primary,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
