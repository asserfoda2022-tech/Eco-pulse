import 'package:flutter/material.dart';
import 'package:project_1/screens/community_screen.dart';
import 'package:project_1/data/governorate_data.dart';
import 'package:project_1/models/earth_data_model.dart';
import 'package:project_1/screens/about_screen.dart';
import 'package:project_1/screens/analyze_screen.dart';
import 'package:project_1/screens/community_screen.dart';
import 'package:project_1/screens/explore_screen.dart';
import 'package:project_1/screens/profile_screen.dart';
import 'package:project_1/screens/ai_chat_screen.dart';
import 'package:project_1/services/analysis_service.dart';
import 'package:project_1/services/auth_service.dart';
import 'package:project_1/services/nasa_api_service.dart';
import 'package:project_1/theme/app_colors.dart';
import 'package:project_1/theme/app_language.dart';
import 'package:project_1/theme/app_text_styles.dart';
import 'package:project_1/utils/app_constants.dart';
import 'package:project_1/utils/app_helpers.dart';
import 'package:project_1/utils/app_routes.dart';
import 'package:project_1/widgets/bottom_nav_bar.dart';
import 'package:project_1/widgets/custom_app_bar.dart';
import 'package:project_1/widgets/custom_button.dart';
import 'package:project_1/widgets/custom_card.dart';
import 'package:project_1/widgets/location_selector.dart';
import 'package:project_1/widgets/phenomenon_card.dart';

/// Main shell: 5 tabs + bottom navigation bar.
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  static const List<Widget> _tabs = [
    HomeTab(),
    AnalyzeScreen(),
    ExploreScreen(),
    AboutScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: AppState.tabIndex,
      builder: (context, index, _) {
        return Scaffold(
          body: AppBackground(
            child: SafeArea(
              bottom: false,
              child: IndexedStack(index: index, children: _tabs),
            ),
          ),
          bottomNavigationBar: AppBottomNavBar(
            currentIndex: index,
            onTap: (i) => AppState.tabIndex.value = i,
          ),
        );
      },
    );
  }
}

/// First tab: welcome card, governorate selector and the latest values.
class HomeTab extends StatefulWidget {
  const HomeTab({super.key});

  @override
  State<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> {
  GovernorateClimate? _climate;
  bool _loading = true;

  static const List<EarthVariable> _tiles = [
    EarthVariables.temperature,
    EarthVariables.rainfall,
    EarthVariables.soilMoisture,
    EarthVariables.humidity,
  ];

  @override
  void initState() {
    super.initState();
    AppState.selectedGovernorate.addListener(_onGovernorateChanged);
    AppState.tabIndex.addListener(_onTabChanged);
    _load();
  }

  @override
  void dispose() {
    AppState.selectedGovernorate.removeListener(_onGovernorateChanged);
    AppState.tabIndex.removeListener(_onTabChanged);
    super.dispose();
  }

  void _onTabChanged() {
    if (mounted && AppState.tabIndex.value == 0) setState(() {});
  }

  void _onGovernorateChanged() {
    setState(() => _loading = true);
    _load();
  }

  Future<void> _load() async {
    final g = AppState.selectedGovernorate.value;
    final climate = await NasaApiService.fetchClimate(g);
    if (!mounted) return;
    if (g.id != AppState.selectedGovernorate.value.id) return;

    setState(() {
      _climate = climate;
      _loading = false;
    });
  }

  String _valueText(EarthVariable v) {
    if (_loading || _climate == null) return '--';
    final latest = _climate!.series[v.id]?.latest;
    if (latest == null) return '--';
    return '${AppHelpers.fmt(latest, v.decimals)} ${v.unit}';
  }

  @override
  Widget build(BuildContext context) {
    final gov = AppState.selectedGovernorate.value;
    final user = AuthService.instance.user;
    final name = (user == null || user.isGuest)
        ? context.tr('Explorer', 'أيها المستكشف')
        : user.name.split(' ').first;
    final history = AnalysisService.history;

    return ListView(
      padding: const EdgeInsets.only(bottom: 28),
      children: [
        CustomAppBar(
          title: AppConstants.appName,
          subtitle: context.tr(
            'Closer to nature, climate-aware',
            'أقرب للطبيعة، واعٍ بالمناخ',
          ),
          showLogo: true,
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              AppIconButton(
                icon: Icons.forum_outlined,
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const CommunityScreen(),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              AppIconButton(
                icon: Icons.notifications_none_rounded,
                onTap: () => AppHelpers.snack(
                  context,
                  context.tr(
                    'No new notifications',
                    'لا توجد إشعارات جديدة',
                  ),
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 12),

        // Welcome Card
        GlassCard(
          margin: const EdgeInsets.symmetric(horizontal: 20),
          padding: const EdgeInsets.all(20),
          radius: 24,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                context.tr('Welcome, $name!', 'أهلًا، $name!'),
                style: AppTextStyles.h1.copyWith(fontSize: 26),
              ),
              const SizedBox(height: 8),
              Text(
                context.tr(
                  'Discover environmental trends across Egypt.',
                  'اكتشف اتجاهات البيئة في أنحاء مصر.',
                ),
                style: AppTextStyles.body,
              ),
            ],
          ),
        ),

        // EcoPulse AI Assistant Button
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
          child: CustomButton(
            label: context.tr(
              'Chat with EcoPulse AI',
              'تحدث مع مساعد EcoPulse الذكي',
            ),
            icon: Icons.smart_toy_rounded,
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const AIChatScreen(),
                ),
              );
            },
          ),
        ),

        SectionTitle(
          context.tr('Start Your Investigation', 'ابدأ تحقيقك'),
        ),

        LocationSelector(
          selected: gov,
          onChanged: (g) => AppState.selectedGovernorate.value = g,
        ),

        Padding(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
          child: CustomButton(
            label: context.tr(
              'Investigate ${gov.nameEn}',
              'حقّق في ${gov.nameAr}',
            ),
            icon: Icons.search_rounded,
            onPressed: () => AppState.tabIndex.value = 1,
          ),
        ),

        SectionTitle(
          context.tr('Explore Earth Trends', 'استكشف اتجاهات الأرض'),
          trailing: _loading
              ? const SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: AppColors.primary,
                  ),
                )
              : null,
        ),

        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: 1.45,
            children: [
              for (final v in _tiles)
                PhenomenonCard(
                  variable: v,
                  value: _valueText(v),
                  onTap: () => AppState.tabIndex.value = 1,
                ),
            ],
          ),
        ),

        Padding(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
          child: Center(
            child: Text(
              (_climate?.isSample ?? false)
                  ? context.tr(
                      'Offline: showing illustrative sample data',
                      'بدون اتصال: عرض بيانات توضيحية تجريبية',
                    )
                  : context.tr(
                      'Latest annual average from NASA POWER, not live monitoring',
                      'آخر متوسط سنوي من NASA POWER، وليس رصدًا لحظيًا',
                    ),
              textAlign: TextAlign.center,
              style: AppTextStyles.caption,
            ),
          ),
        ),

        if (history.isNotEmpty) ...[
          SectionTitle(
            context.tr('Recent investigations', 'تحقيقات حديثة'),
          ),
          for (final inv in history.take(2))
            GlassCard(
              margin: const EdgeInsets.fromLTRB(20, 0, 20, 10),
              onTap: () => Navigator.pushNamed(
                context,
                AppRoutes.results,
                arguments: inv,
              ),
              child: Row(
                children: [
                  const Icon(
                    Icons.history_rounded,
                    color: AppColors.primary,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          inv.governorate.name(context.isAr),
                          style: AppTextStyles.h3,
                        ),
                        Text(
                          '${inv.startYear}-${inv.endYear} · '
                          '${inv.significantResults.length}/${inv.results.length} '
                          '${context.tr('significant', 'معنوية')}',
                          style: AppTextStyles.caption,
                        ),
                      ],
                    ),
                  ),
                  const Icon(
                    Icons.chevron_right_rounded,
                    color: AppColors.textMuted,
                  ),
                ],
              ),
            ),
        ],
      ],
    );
  }
}
