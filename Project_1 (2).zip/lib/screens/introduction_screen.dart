import 'package:flutter/material.dart';
import 'package:project_1/theme/app_colors.dart';
import 'package:project_1/theme/app_language.dart';
import 'package:project_1/theme/app_text_styles.dart';
import 'package:project_1/utils/app_routes.dart';
import 'package:project_1/widgets/custom_button.dart';
import 'package:project_1/widgets/custom_card.dart';

class IntroductionScreen extends StatefulWidget {
  const IntroductionScreen({super.key});

  @override
  State<IntroductionScreen> createState() => _IntroductionScreenState();
}

class _IntroPage {
  final IconData icon;
  final String titleEn;
  final String titleAr;
  final String bodyEn;
  final String bodyAr;
  const _IntroPage(
      this.icon, this.titleEn, this.titleAr, this.bodyEn, this.bodyAr);
}

class _IntroductionScreenState extends State<IntroductionScreen> {
  final PageController _controller = PageController();
  int _page = 0;

  static const List<_IntroPage> _pages = [
    _IntroPage(
      Icons.public,
      'Be an Earth System Trend Detective',
      'كن محقّق اتجاهات نظام الأرض',
      'The Earth is always changing. Eco Pulse turns NASA satellite and model data into clear answers about what is changing around you.',
      'الأرض في تغيّر دائم. يحوّل Eco Pulse بيانات ناسا إلى إجابات واضحة عمّا يتغيّر حولك.',
    ),
    _IntroPage(
      Icons.location_on_outlined,
      'Pick any of Egypt\'s 27 governorates',
      'اختر أي محافظة من محافظات مصر الـ٢٧',
      'Temperature, rainfall, soil moisture, humidity and wind: see how each one changed over more than 20 years where you live.',
      'الحرارة والأمطار ورطوبة التربة والرطوبة والرياح: شاهد كيف تغيّر كل منها خلال أكثر من ٢٠ عامًا في منطقتك.',
    ),
    _IntroPage(
      Icons.insights,
      'Know what is real, and what it affects',
      'اعرف ما هو حقيقي وما الذي يؤثر عليه',
      'We test every trend statistically, so you see only changes scientists call "significant", with their impact on farming, water and health.',
      'نختبر كل اتجاه إحصائيًا، فترى فقط التغيّرات التي يسمّيها العلماء «معنوية» مع تأثيرها على الزراعة والمياه والصحة.',
    ),
  ];

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _next() {
    if (_page == _pages.length - 1) {
      _finish();
    } else {
      _controller.nextPage(
        duration: const Duration(milliseconds: 350),
        curve: Curves.easeOut,
      );
    }
  }

  void _finish() => Navigator.pushReplacementNamed(context, AppRoutes.login);

  @override
  Widget build(BuildContext context) {
    final isLast = _page == _pages.length - 1;
    return Scaffold(
      body: AppBackground(
        child: SafeArea(
          child: Column(
            children: [
              Align(
                alignment: AlignmentDirectional.centerEnd,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
                  child: TextButton(
                    onPressed: _finish,
                    child: Text(
                      context.tr('Skip', 'تخطي'),
                      style: const TextStyle(color: AppColors.textSecondary),
                    ),
                  ),
                ),
              ),
              Expanded(
                child: PageView.builder(
                  controller: _controller,
                  itemCount: _pages.length,
                  onPageChanged: (i) => setState(() => _page = i),
                  itemBuilder: (context, i) {
                    final p = _pages[i];
                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 28),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 140,
                            height: 140,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: AppColors.card,
                              border: Border.all(color: AppColors.cardBorder),
                            ),
                            child: Icon(p.icon,
                                size: 66, color: AppColors.primary),
                          ),
                          const SizedBox(height: 36),
                          Text(
                            context.tr(p.titleEn, p.titleAr),
                            textAlign: TextAlign.center,
                            style: AppTextStyles.h1.copyWith(fontSize: 26),
                          ),
                          const SizedBox(height: 14),
                          Text(
                            context.tr(p.bodyEn, p.bodyAr),
                            textAlign: TextAlign.center,
                            style: AppTextStyles.body.copyWith(fontSize: 15),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  for (var i = 0; i < _pages.length; i++)
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 250),
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      width: i == _page ? 26 : 8,
                      height: 8,
                      decoration: BoxDecoration(
                        color: i == _page
                            ? AppColors.primary
                            : AppColors.cardBorder,
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(24, 24, 24, 28),
                child: CustomButton(
                  label: isLast
                      ? context.tr('Get started', 'ابدأ الآن')
                      : context.tr('Next', 'التالي'),
                  icon: isLast ? Icons.rocket_launch_outlined : null,
                  onPressed: _next,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
