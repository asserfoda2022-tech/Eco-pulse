import 'package:flutter/material.dart';
import 'package:project_1/models/earth_data_model.dart';
import 'package:project_1/models/investigation_model.dart';
import 'package:project_1/theme/app_colors.dart';
import 'package:project_1/theme/app_language.dart';
import 'package:project_1/theme/app_text_styles.dart';
import 'package:project_1/utils/app_constants.dart';
import 'package:project_1/utils/app_helpers.dart';
import 'package:project_1/widgets/custom_app_bar.dart';
import 'package:project_1/widgets/custom_card.dart';
import 'package:project_1/widgets/phenomenon_card.dart';
import 'package:project_1/widgets/trend_chart.dart';

class InvestigationDetailsArgs {
  final InvestigationModel investigation;
  final TrendResult result;
  const InvestigationDetailsArgs(this.investigation, this.result);
}

/// Deep dive into one variable of an investigation.
class InvestigationDetailsScreen extends StatelessWidget {
  final InvestigationDetailsArgs args;
  const InvestigationDetailsScreen({super.key, required this.args});

  @override
  Widget build(BuildContext context) {
    final ar = context.isAr;
    final inv = args.investigation;
    final r = args.result;
    final v = r.variable;
    final color = AppHelpers.trendColor(r);
    final cd = AppHelpers.changeDecimals(v.decimals);
    final notes = inv.impacts.where((n) => n.variableId == v.id).toList();

    return Scaffold(
      body: AppBackground(
        child: SafeArea(
          child: Column(
            children: [
              CustomAppBar(
                title: v.name(ar),
                subtitle:
                    '${inv.governorate.name(ar)} · ${r.startYear}-${r.endYear}',
                showBack: true,
              ),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.only(bottom: 28),
                  children: [
                    if (inv.isSample)
                      InfoBanner(
                        icon: Icons.cloud_off_outlined,
                        text: context.tr('Illustrative SAMPLE data (offline).',
                            'بيانات توضيحية تجريبية (بدون اتصال).'),
                      ),
                    const SizedBox(height: 12),

                    // Verdict
                    GlassCard(
                      margin: const EdgeInsets.symmetric(horizontal: 20),
                      padding: const EdgeInsets.all(20),
                      radius: 24,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(AppHelpers.trendIcon(r),
                                  color: color, size: 28),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  AppHelpers.verdict(context, r),
                                  style:
                                      AppTextStyles.h2.copyWith(color: color),
                                ),
                              ),
                              SignificanceChip(significant: r.significant),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Text(
                            r.significant
                                ? context.tr(
                                    'p = ${AppHelpers.fmtP(r.pValue)} is below ${AppConstants.alpha}: this change is very unlikely to be only natural year-to-year variability.',
                                    'قيمة p = ${AppHelpers.fmtP(r.pValue)} أقل من ${AppConstants.alpha}: من غير المرجّح أن يكون هذا التغيّر مجرد تباين طبيعي بين السنوات.')
                                : context.tr(
                                    'p = ${AppHelpers.fmtP(r.pValue)} is not below ${AppConstants.alpha}: the change could easily be natural variability, so scientists would not call it significant.',
                                    'قيمة p = ${AppHelpers.fmtP(r.pValue)} ليست أقل من ${AppConstants.alpha}: قد يكون التغيّر تباينًا طبيعيًا، لذلك لا يسمّيه العلماء معنويًا.'),
                            style: AppTextStyles.body,
                          ),
                        ],
                      ),
                    ),

                    // Chart
                    SectionTitle(
                        context.tr('Change over time', 'التغيّر عبر الزمن')),
                    GlassCard(
                      margin: const EdgeInsets.symmetric(horizontal: 20),
                      padding: const EdgeInsets.fromLTRB(8, 12, 8, 8),
                      child: Column(
                        children: [
                          Directionality(
                            textDirection: TextDirection.ltr,
                            child: TrendChart(
                              points: r.points,
                              slope: r.slopePerYear,
                              intercept: r.intercept,
                              color: AppColors.primary,
                              unit: v.unit,
                              decimals:
                                  v.decimals + (v.id == 'rainfall' ? 1 : 0),
                            ),
                          ),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              _legend(AppColors.primary,
                                  context.tr('Annual mean', 'المتوسط السنوي')),
                              const SizedBox(width: 18),
                              _legend(Colors.white,
                                  context.tr('Trend (Sen)', 'الاتجاه (سين)')),
                            ],
                          ),
                        ],
                      ),
                    ),

                    // Numbers
                    SectionTitle(context.tr('The numbers', 'الأرقام')),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Column(
                        children: [
                          Row(children: [
                            _stat(
                              context.tr(
                                  'Change per decade', 'التغيّر لكل عقد'),
                              '${AppHelpers.fmtSigned(r.slopePerDecade, cd)} ${v.unit}',
                              color,
                            ),
                            const SizedBox(width: 12),
                            _stat(
                              context.tr('Total change', 'التغيّر الكلي'),
                              '${AppHelpers.fmtSigned(r.totalChange, cd)} ${v.unit}',
                              color,
                            ),
                          ]),
                          const SizedBox(height: 12),
                          Row(children: [
                            _stat(
                              context.tr('Relative change', 'التغيّر النسبي'),
                              AppHelpers.fmtPercent(r.percentChange),
                              color,
                            ),
                            const SizedBox(width: 12),
                            _stat(
                              context.tr('Period mean', 'متوسط الفترة'),
                              '${AppHelpers.fmt(r.mean, v.decimals)} ${v.unit}',
                              AppColors.textPrimary,
                            ),
                          ]),
                          const SizedBox(height: 12),
                          Row(children: [
                            _stat('p-value', AppHelpers.fmtP(r.pValue),
                                AppColors.textPrimary),
                            const SizedBox(width: 12),
                            _stat(
                              context.tr('Kendall τ', 'معامل كندال τ'),
                              AppHelpers.fmtSigned(r.tau, 2),
                              AppColors.textPrimary,
                            ),
                            const SizedBox(width: 12),
                            _stat('R²', AppHelpers.fmt(r.rSquared, 2),
                                AppColors.textPrimary),
                          ]),
                        ],
                      ),
                    ),

                    // Impacts
                    SectionTitle(
                        context.tr('What it affects', 'ما الذي يتأثر')),
                    if (notes.isEmpty)
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: Text(
                          context.tr(
                              'No impact is flagged because the change is not statistically significant.',
                              'لا توجد تأثيرات مُشار إليها لأن التغيّر ليس معنويًا إحصائيًا.'),
                          style: AppTextStyles.body,
                        ),
                      )
                    else
                      for (final n in notes)
                        GlassCard(
                          margin: const EdgeInsets.fromLTRB(20, 0, 20, 10),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Icon(n.icon, color: AppColors.primary),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(n.sector(ar), style: AppTextStyles.h3),
                                    const SizedBox(height: 4),
                                    Text(n.text(ar), style: AppTextStyles.body),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),

                    // How to read
                    InfoBanner(
                      icon: Icons.info_outline_rounded,
                      color: AppColors.primary,
                      text: context.tr(
                          'About this variable: ${v.description(false)} Impacts are general guidance, not a local forecast.',
                          'عن هذا المتغيّر: ${v.description(true)} التأثيرات إرشادات عامة وليست توقعًا محليًا.'),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _legend(Color c, String label) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(width: 14, height: 3, color: c),
        const SizedBox(width: 6),
        Text(label, style: AppTextStyles.caption),
      ],
    );
  }

  Widget _stat(String label, String value, Color valueColor) {
    return Expanded(
      child: GlassCard(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label,
                style: AppTextStyles.caption,
                maxLines: 2,
                overflow: TextOverflow.ellipsis),
            const SizedBox(height: 6),
            FittedBox(
              fit: BoxFit.scaleDown,
              alignment: AlignmentDirectional.centerStart,
              child: Text(
                value,
                style: AppTextStyles.h3
                    .copyWith(color: valueColor, fontWeight: FontWeight.w800),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
