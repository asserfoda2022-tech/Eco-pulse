import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:project_1/models/community_post.dart';
import 'package:project_1/services/community_service.dart';
import 'package:project_1/data/governorate_data.dart';
import 'package:project_1/theme/app_colors.dart';
import 'package:project_1/theme/app_language.dart';
import 'package:project_1/theme/app_text_styles.dart';
import 'package:project_1/utils/app_helpers.dart';
import 'package:project_1/widgets/custom_app_bar.dart';
import 'package:project_1/widgets/custom_button.dart';
import 'package:project_1/widgets/custom_card.dart';
import 'package:project_1/widgets/location_selector.dart';

class AddPostScreen extends StatefulWidget {
  const AddPostScreen({super.key});

  @override
  State<AddPostScreen> createState() => _AddPostScreenState();
}

class _AddPostScreenState extends State<AddPostScreen> {
  static const int _minChars = 10;
  static const int _maxChars = 500;

  final _controller = TextEditingController();
  final _picker = ImagePicker();

  Governorate _gov = AppState.selectedGovernorate.value;
  String _typeId = PhenomenonType.all.first.id;
  XFile? _image;
  bool _sending = false;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _pick(ImageSource source) async {
    try {
      final file = await _picker.pickImage(
        source: source,
        maxWidth: 1280,
        imageQuality: 80,
      );
      if (file != null && mounted) setState(() => _image = file);
    } catch (_) {
      if (!mounted) return;
      AppHelpers.snack(
        context,
        context.tr('Could not open the image.', 'تعذّر فتح الصورة.'),
      );
    }
  }

  void _showSourceSheet() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF14382D),
      builder: (sheetContext) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.photo_library_outlined,
                  color: AppColors.primary),
              title: Text(context.tr('Gallery', 'المعرض'),
                  style: AppTextStyles.h3),
              onTap: () {
                Navigator.pop(sheetContext);
                _pick(ImageSource.gallery);
              },
            ),
            ListTile(
              leading: const Icon(Icons.photo_camera_outlined,
                  color: AppColors.primary),
              title: Text(context.tr('Camera', 'الكاميرا'),
                  style: AppTextStyles.h3),
              onTap: () {
                Navigator.pop(sheetContext);
                _pick(ImageSource.camera);
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _submit() async {
    final text = _controller.text.trim();
    if (text.length < _minChars) {
      AppHelpers.snack(
        context,
        context.tr(
          'Please write at least $_minChars characters.',
          'من فضلك اكتب $_minChars أحرف على الأقل.',
        ),
      );
      return;
    }
    setState(() => _sending = true);
    try {
      await CommunityService.instance.addPost(
        governorateId: _gov.id,
        phenomenonId: _typeId,
        description: text,
        image: _image,
      );
      if (!mounted) return;
      Navigator.pop(context);
      AppHelpers.snack(
        context,
        context.tr('Your post was published.', 'تم نشر منشورك.'),
      );
    } catch (_) {
      if (!mounted) return;
      setState(() => _sending = false);
      AppHelpers.snack(
        context,
        context.tr(
          'Could not publish the post. Please try again.',
          'تعذّر نشر المنشور. حاول مرة أخرى.',
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final isAr = context.isAr;
    return Scaffold(
      body: AppBackground(
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.only(bottom: 28),
            children: [
              CustomAppBar(
                title: context.tr('New observation', 'ملاحظة جديدة'),
                showBack: true,
              ),

              // Optional photo
              GlassCard(
                margin: const EdgeInsets.fromLTRB(20, 12, 20, 0),
                padding: EdgeInsets.zero,
                onTap: _sending ? null : _showSourceSheet,
                child: _image == null
                    ? SizedBox(
                        height: 140,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(Icons.add_a_photo_outlined,
                                color: AppColors.primary, size: 32),
                            const SizedBox(height: 8),
                            Text(
                              context.tr('Add a photo (optional)',
                                  'أضف صورة (اختياري)'),
                              style: AppTextStyles.body,
                            ),
                          ],
                        ),
                      )
                    : Stack(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(20),
                            child: FutureBuilder<Uint8List>(
                              future: _image!.readAsBytes(),
                              builder: (_, s) => s.hasData
                                  ? Image.memory(s.data!,
                                      height: 220,
                                      width: double.infinity,
                                      fit: BoxFit.cover)
                                  : const SizedBox(height: 220),
                            ),
                          ),
                          PositionedDirectional(
                            top: 8,
                            end: 8,
                            child: AppIconButton(
                              icon: Icons.close_rounded,
                              onTap: _sending
                                  ? null
                                  : () => setState(() => _image = null),
                            ),
                          ),
                        ],
                      ),
              ),

              SectionTitle(context.tr('Governorate', 'المحافظة')),
              LocationSelector(
                selected: _gov,
                onChanged: (g) => setState(() => _gov = g),
              ),

              SectionTitle(context.tr('Type of phenomenon', 'نوع الظاهرة')),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final t in PhenomenonType.all)
                      ChoiceChip(
                        avatar: Icon(
                          t.icon,
                          size: 18,
                          color: _typeId == t.id
                              ? AppColors.onPrimary
                              : AppColors.primary,
                        ),
                        label: Text(t.name(isAr)),
                        selected: _typeId == t.id,
                        showCheckmark: false,
                        selectedColor: AppColors.primary,
                        backgroundColor: AppColors.card,
                        side: const BorderSide(color: AppColors.cardBorder),
                        labelStyle: TextStyle(
                          color: _typeId == t.id
                              ? AppColors.onPrimary
                              : AppColors.textPrimary,
                          fontWeight: FontWeight.w600,
                        ),
                        onSelected: _sending
                            ? null
                            : (_) => setState(() => _typeId = t.id),
                      ),
                  ],
                ),
              ),

              SectionTitle(context.tr('Description', 'الوصف')),
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 20),
                decoration: BoxDecoration(
                  color: AppColors.card,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: AppColors.cardBorder),
                ),
                child: TextField(
                  controller: _controller,
                  enabled: !_sending,
                  minLines: 4,
                  maxLines: 8,
                  maxLength: _maxChars,
                  style:
                      AppTextStyles.body.copyWith(color: AppColors.textPrimary),
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.all(16),
                    hintText: context.tr(
                      'Describe what you observed...',
                      'اوصف ما لاحظته...',
                    ),
                    hintStyle: AppTextStyles.body,
                  ),
                ),
              ),

              Padding(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
                child: CustomButton(
                  label: context.tr('Publish', 'نشر'),
                  icon: Icons.send_rounded,
                  loading: _sending,
                  onPressed: _submit,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
