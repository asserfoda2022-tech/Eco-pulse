import 'package:flutter/material.dart';
import 'package:project_1/services/auth_service.dart';
import 'package:project_1/theme/app_colors.dart';
import 'package:project_1/theme/app_language.dart';
import 'package:project_1/theme/app_text_styles.dart';
import 'package:project_1/utils/app_constants.dart';
import 'package:project_1/utils/app_routes.dart';
import 'package:project_1/widgets/custom_button.dart';
import 'package:project_1/widgets/custom_card.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _name = TextEditingController();
  final TextEditingController _email = TextEditingController();
  final TextEditingController _password = TextEditingController();

  bool _isSignUp = false;
  bool _obscure = true;
  bool _busy = false;
  String? _errorCode;

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    setState(() {
      _busy = true;
      _errorCode = null;
    });
    final String? code = _isSignUp
        ? await AuthService.instance.register(
            name: _name.text,
            email: _email.text,
            password: _password.text,
          )
        : await AuthService.instance.login(
            email: _email.text,
            password: _password.text,
          );
    if (!mounted) return;
    if (code == null) {
      Navigator.pushReplacementNamed(context, AppRoutes.home);
    } else {
      setState(() {
        _busy = false;
        _errorCode = code;
      });
    }
  }

  void _guest() {
    AuthService.instance.continueAsGuest();
    Navigator.pushReplacementNamed(context, AppRoutes.home);
  }

  String _errorText(BuildContext context, String code) {
    switch (code) {
      case 'name':
        return context.tr('Please enter your name.', 'من فضلك أدخل اسمك.');
      case 'email':
        return context.tr('Please enter a valid email.',
            'من فضلك أدخل بريدًا إلكترونيًا صحيحًا.');
      case 'password':
        return context.tr('Password must be at least 6 characters.',
            'كلمة المرور يجب ألا تقل عن ٦ أحرف.');
      case 'exists':
        return context.tr(
            'This email is already registered.', 'هذا البريد مسجّل بالفعل.');
      default:
        return context.tr('Wrong email or password.',
            'البريد الإلكتروني أو كلمة المرور غير صحيحة.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AppBackground(
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Align(
                  alignment: AlignmentDirectional.centerEnd,
                  child: TextButton.icon(
                    onPressed: AppLanguage.toggle,
                    icon: const Icon(Icons.language,
                        size: 18, color: AppColors.textSecondary),
                    label: Text(
                      context.tr('العربية', 'English'),
                      style: const TextStyle(color: AppColors.textSecondary),
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    color: AppColors.card,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: AppColors.cardBorder),
                  ),
                  child: const Icon(Icons.eco_rounded,
                      color: AppColors.primary, size: 34),
                ),
                const SizedBox(height: 20),
                Text(AppConstants.appName,
                    style: AppTextStyles.h1.copyWith(letterSpacing: 2)),
                const SizedBox(height: 6),
                Text(
                  _isSignUp
                      ? context.tr('Create your explorer account',
                          'أنشئ حساب المستكشف الخاص بك')
                      : context.tr('Welcome back, Explorer',
                          'أهلًا بعودتك أيها المستكشف'),
                  style: AppTextStyles.body,
                ),
                const SizedBox(height: 28),
                if (_isSignUp) ...[
                  _field(
                    controller: _name,
                    hint: context.tr('Full name', 'الاسم'),
                    icon: Icons.person_outline,
                  ),
                  const SizedBox(height: 14),
                ],
                _field(
                  controller: _email,
                  hint: context.tr('Email', 'البريد الإلكتروني'),
                  icon: Icons.mail_outline,
                  keyboard: TextInputType.emailAddress,
                ),
                const SizedBox(height: 14),
                _field(
                  controller: _password,
                  hint: context.tr('Password', 'كلمة المرور'),
                  icon: Icons.lock_outline,
                  obscure: _obscure,
                  suffix: IconButton(
                    onPressed: () => setState(() => _obscure = !_obscure),
                    icon: Icon(
                      _obscure
                          ? Icons.visibility_outlined
                          : Icons.visibility_off_outlined,
                      color: AppColors.textMuted,
                      size: 20,
                    ),
                  ),
                ),
                if (_errorCode != null) ...[
                  const SizedBox(height: 12),
                  Text(
                    _errorText(context, _errorCode!),
                    style:
                        const TextStyle(color: AppColors.error, fontSize: 13),
                  ),
                ],
                const SizedBox(height: 22),
                CustomButton(
                  label: _isSignUp
                      ? context.tr('Create account', 'إنشاء حساب')
                      : context.tr('Log in', 'تسجيل الدخول'),
                  loading: _busy,
                  onPressed: _submit,
                ),
                const SizedBox(height: 12),
                CustomButton(
                  label: context.tr('Continue as guest', 'المتابعة كزائر'),
                  outlined: true,
                  onPressed: _busy ? null : _guest,
                ),
                const SizedBox(height: 18),
                Center(
                  child: TextButton(
                    onPressed: () => setState(() {
                      _isSignUp = !_isSignUp;
                      _errorCode = null;
                    }),
                    child: Text(
                      _isSignUp
                          ? context.tr('Already have an account? Log in',
                              'لديك حساب؟ سجّل الدخول')
                          : context.tr('New here? Create an account',
                              'مستخدم جديد؟ أنشئ حسابًا'),
                      style: const TextStyle(color: AppColors.primary),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _field({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    bool obscure = false,
    Widget? suffix,
    TextInputType? keyboard,
  }) {
    return TextField(
      controller: controller,
      obscureText: obscure,
      keyboardType: keyboard,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: AppColors.textMuted),
        prefixIcon: Icon(icon, color: AppColors.textSecondary, size: 20),
        suffixIcon: suffix,
        filled: true,
        fillColor: AppColors.card,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: AppColors.cardBorder),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: AppColors.cardBorder),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: AppColors.primary, width: 1.5),
        ),
      ),
    );
  }
}
