import 'package:flutter/material.dart';
import 'package:project_1/theme/app_colors.dart';
import 'package:project_1/theme/app_language.dart';
import 'package:project_1/theme/app_text_styles.dart';
import 'package:project_1/utils/app_constants.dart';
import 'package:project_1/widgets/custom_app_bar.dart';
import 'package:project_1/widgets/custom_card.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.only(bottom: 28),
      children: [
        CustomAppBar(
          title: context.tr('About', 'عن التطبيق'),
          subtitle: 'Eco Pulse · NASA Space Apps 2026',
        ),
        const SizedBox(height: 8),
        GlassCard(
          margin: const EdgeInsets.symmetric(horizontal: 20),
          padding: const EdgeInsets.all(20),
          radius: 24,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Be an Earth System Trend Detective',
                  style: AppTextStyles.h2),
              const SizedBox(height: 10),
              Text(
                context.tr(
                    'Eco Pulse lets anyone pick a governorate of Egypt and see which Earth-science variables are changing, where, by how much, and whether the change is statistically significant.',
                    'يتيح Eco Pulse لأي شخص اختيار محافظة في مصر ومعرفة أي متغيرات الأرض تتغيّر، وأين، وبكم، وهل التغيّر معنوي إحصائيًا.'),
                style: AppTextStyles.body,
              ),
            ],
          ),
        ),
        SectionTitle(context.tr('How it works', 'كيف يعمل')),
        _step(
            context,
            Icons.cloud_download_outlined,
            '1',
            context.tr('NASA data', 'بيانات ناسا'),
            context.tr(
                'Monthly data from the NASA POWER API (satellite + MERRA-2 model) is converted to annual means for ${AppConstants.firstYear}-${AppConstants.lastYear}.',
                'تُحوَّل البيانات الشهرية من NASA POWER (أقمار صناعية + نموذج MERRA-2) إلى متوسطات سنوية للفترة ${AppConstants.firstYear}-${AppConstants.lastYear}.')),
        _step(
            context,
            Icons.show_chart,
            '2',
            context.tr('Trend detection', 'اكتشاف الاتجاه'),
            context.tr(
                'Sen\'s slope gives the size of change per year; it is robust to outliers.',
                'ميل سين يعطي مقدار التغيّر سنويًا وهو مقاوم للقيم الشاذة.')),
        _step(
            context,
            Icons.verified_outlined,
            '3',
            context.tr('Significance', 'المعنوية'),
            context.tr(
                'The Mann-Kendall test checks if the trend is more than random variability. We call it significant when p < ${AppConstants.alpha} (95% confidence).',
                'يختبر اختبار مان-كندال ما إذا كان الاتجاه أكبر من التباين العشوائي. نعتبره معنويًا عندما p < ${AppConstants.alpha} (ثقة ٩٥٪).')),
        _step(
            context,
            Icons.public,
            '4',
            context.tr('Impacts', 'التأثيرات'),
            context.tr(
                'For every significant change we show which sectors it usually affects: farming, water, energy and health.',
                'لكل تغيّر معنوي نعرض القطاعات التي يؤثر عليها عادةً: الزراعة والمياه والطاقة والصحة.')),
        SectionTitle(context.tr('Good to know', 'معلومات مهمة')),
        InfoBanner(
          icon: Icons.info_outline_rounded,
          color: AppColors.primary,
          text: context.tr(
              'Values are for the capital city of each governorate (about 50 km grid cells). A trend in one place can be the opposite of another place even when the same process drives both. That is why Eco Pulse compares governorates.',
              'القيم لعاصمة كل محافظة (خلايا شبكية بحجم ~٥٠ كم). قد يختلف الاتجاه من مكان لآخر حتى لو كانت العملية المسبِّبة واحدة، ولهذا يقارن Eco Pulse بين المحافظات.'),
        ),
        InfoBanner(
          icon: Icons.warning_amber_rounded,
          text: context.tr(
              'Illustrative tool for exploration, not live monitoring or an official forecast.',
              'أداة توضيحية للاستكشاف، وليست رصدًا لحظيًا أو توقعًا رسميًا.'),
        ),
        const SizedBox(height: 20),
        Center(
          child: Text('Eco Pulse v1.0.0', style: AppTextStyles.caption),
        ),
      ],
    );
  }

  Widget _step(BuildContext context, IconData icon, String n, String title,
      String body) {
    return GlassCard(
      margin: const EdgeInsets.fromLTRB(20, 0, 20, 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.14),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: AppColors.primary),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: AppTextStyles.h3),
                const SizedBox(height: 4),
                Text(body, style: AppTextStyles.body),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
