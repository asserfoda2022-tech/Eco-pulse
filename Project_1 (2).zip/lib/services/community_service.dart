import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'package:project_1/models/community_post.dart';
import 'package:project_1/services/auth_service.dart';

/// Talks to Firebase for the community: posts (Firestore), images (Storage)
/// and the user identity (Firebase Auth).
class CommunityService {
  CommunityService._();
  static final CommunityService instance = CommunityService._();

  static const String _collection = 'community_posts';

  CollectionReference<Map<String, dynamic>> get _posts =>
      FirebaseFirestore.instance.collection(_collection);

  /// Latest posts first. Filtering by governorate is done on the device so
  /// no Firestore composite index is needed.
  Stream<List<CommunityPost>> postsStream({int limit = 100}) {
    return _posts
        .orderBy('createdAt', descending: true)
        .limit(limit)
        .snapshots()
        .map((s) => s.docs.map(CommunityPost.fromDoc).toList());
  }

  /// The app's own login is local, so we give every device a Firebase
  /// identity (anonymous) to own its posts. Needs the "Anonymous" sign-in
  /// provider enabled in Firebase Console -> Authentication.
  Future<User> _ensureFirebaseUser() async {
    final auth = FirebaseAuth.instance;
    final current = auth.currentUser;
    if (current != null) return current;
    final cred = await auth.signInAnonymously();
    return cred.user!;
  }

  Future<void> addPost({
    required String governorateId,
    required String phenomenonId,
    required String description,
    XFile? image,
  }) async {
    final user = await _ensureFirebaseUser();

    String? imageUrl;
    if (image != null) {
      final bytes = await image.readAsBytes();
      final ref = FirebaseStorage.instance.ref(
        '$_collection/${user.uid}/${DateTime.now().millisecondsSinceEpoch}.jpg',
      );
      await ref.putData(bytes, SettableMetadata(contentType: 'image/jpeg'));
      imageUrl = await ref.getDownloadURL();
    }

    final appUser = AuthService.instance.user;
    final name = (appUser == null || appUser.isGuest) ? '' : appUser.name;

    await _posts.add({
      'userId': user.uid,
      'authorName': name,
      'governorateId': governorateId,
      'phenomenonId': phenomenonId,
      'description': description.trim(),
      'imageUrl': imageUrl,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }
}
