import 'package:flutter/foundation.dart';
import 'package:project_1/models/user_model.dart';

class _Account {
  final String name;
  final String password;
  final DateTime joinedAt;
  const _Account(this.name, this.password, this.joinedAt);
}

/// Local (in-memory) authentication for the demo.
///
/// To go to production, replace the bodies of [register] and [login] with
/// Firebase Auth / your own backend. The rest of the app will not change.
///
/// Error codes returned (null means success):
///   'name', 'email', 'password', 'exists', 'credentials'
class AuthService extends ChangeNotifier {
  AuthService._();
  static final AuthService instance = AuthService._();

  final Map<String, _Account> _accounts = <String, _Account>{};
  UserModel? _user;

  UserModel? get user => _user;
  bool get isLoggedIn => _user != null;

  static final RegExp _emailRe = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$');

  Future<String?> register({
    required String name,
    required String email,
    required String password,
  }) async {
    await Future<void>.delayed(const Duration(milliseconds: 600));
    final cleanEmail = email.trim().toLowerCase();
    if (name.trim().length < 2) return 'name';
    if (!_emailRe.hasMatch(cleanEmail)) return 'email';
    if (password.length < 6) return 'password';
    if (_accounts.containsKey(cleanEmail)) return 'exists';

    final now = DateTime.now();
    _accounts[cleanEmail] = _Account(name.trim(), password, now);
    _user = UserModel(
      name: name.trim(),
      email: cleanEmail,
      isGuest: false,
      joinedAt: now,
    );
    notifyListeners();
    return null;
  }

  Future<String?> login({
    required String email,
    required String password,
  }) async {
    await Future<void>.delayed(const Duration(milliseconds: 600));
    final cleanEmail = email.trim().toLowerCase();
    if (!_emailRe.hasMatch(cleanEmail)) return 'email';
    if (password.isEmpty) return 'password';
    final acc = _accounts[cleanEmail];
    if (acc == null || acc.password != password) return 'credentials';

    _user = UserModel(
      name: acc.name,
      email: cleanEmail,
      isGuest: false,
      joinedAt: acc.joinedAt,
    );
    notifyListeners();
    return null;
  }

  void continueAsGuest() {
    _user = UserModel(
      name: 'Explorer',
      email: '',
      isGuest: true,
      joinedAt: DateTime.now(),
    );
    notifyListeners();
  }

  void logout() {
    _user = null;
    notifyListeners();
  }
}
