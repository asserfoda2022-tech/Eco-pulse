import '../data/chatbot_knowledge.dart';

class AIChatService {
  String getResponse(String question) {
    final text = question.toLowerCase().trim();

    if (_containsAny(text, [
      'hello',
      'hi',
      'hey',
      'مرحبا',
      'اهلا',
      'أهلا',
      'السلام عليكم',
    ])) {
      return ChatbotKnowledge.answers['hello']!;
    }

    if (_containsAny(text, [
      'help',
      'مساعدة',
      'ساعدني',
      'تقدر تعمل ايه',
    ])) {
      return ChatbotKnowledge.answers['help']!;
    }

    if (_containsAny(text, [
      'climate change',
      'climate',
      'التغير المناخي',
      'تغير المناخ',
      'المناخ',
    ])) {
      return ChatbotKnowledge.answers['climate']!;
    }

    if (_containsAny(text, [
      'temperature',
      'heat',
      'درجة الحرارة',
      'الحرارة',
    ])) {
      return ChatbotKnowledge.answers['temperature']!;
    }

    if (_containsAny(text, [
      'rainfall',
      'rain',
      'precipitation',
      'الأمطار',
      'المطر',
    ])) {
      return ChatbotKnowledge.answers['rainfall']!;
    }

    if (_containsAny(text, [
      'nasa power',
      'nasa',
      'ناسا',
    ])) {
      return ChatbotKnowledge.answers['nasa']!;
    }

    if (_containsAny(text, [
      'evapotranspiration',
      'التبخر',
    ])) {
      return ChatbotKnowledge.answers['evapotranspiration']!;
    }

    if (_containsAny(text, [
      'global warming',
      'الاحتباس الحراري',
    ])) {
      return ChatbotKnowledge.answers['global warming']!;
    }

    if (_containsAny(text, [
      'vegetation',
      'plants',
      'النباتات',
      'الغطاء النباتي',
    ])) {
      return ChatbotKnowledge.answers['vegetation']!;
    }

    if (_containsAny(text, [
      'soil moisture',
      'soil',
      'رطوبة التربة',
      'التربة',
    ])) {
      return ChatbotKnowledge.answers['soil']!;
    }

    if (_containsAny(text, [
      'water',
      'المياه',
      'الماء',
    ])) {
      return ChatbotKnowledge.answers['water']!;
    }

    if (_containsAny(text, [
      'luxor',
      'الأقصر',
    ])) {
      return ChatbotKnowledge.answers['luxor']!;
    }

    if (_containsAny(text, [
      'alexandria',
      'اسكندرية',
      'الإسكندرية',
    ])) {
      return ChatbotKnowledge.answers['alexandria']!;
    }

    if (_containsAny(text, [
      'egypt',
      'مصر',
    ])) {
      return ChatbotKnowledge.answers['egypt']!;
    }

    if (_containsAny(text, [
      'sustainability',
      'الاستدامة',
    ])) {
      return ChatbotKnowledge.answers['sustainability']!;
    }

    if (_containsAny(text, [
      'power',
    ])) {
      return ChatbotKnowledge.answers['power']!;
    }

    return ChatbotKnowledge.fallback;
  }

  bool _containsAny(String text, List<String> keywords) {
    return keywords.any((keyword) => text.contains(keyword));
  }
}
