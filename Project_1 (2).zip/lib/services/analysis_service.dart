import 'dart:math';

import 'package:project_1/data/governorate_data.dart';
import 'package:project_1/models/earth_data_model.dart';
import 'package:project_1/models/investigation_model.dart';
import 'package:project_1/services/nasa_api_service.dart';
import 'package:project_1/utils/app_constants.dart';

/// Statistical engine of the app.
///
/// Answers the four questions of the challenge:
///   what is changing   -> direction + Sen's slope
///   where              -> run per governorate
///   how much           -> total & relative change
///   is it significant  -> Mann-Kendall test (p < 0.05)
class AnalysisService {
  AnalysisService._();

  static final List<InvestigationModel> history = <InvestigationModel>[];

  static Future<InvestigationModel> runInvestigation({
    required Governorate governorate,
    required List<EarthVariable> variables,
    required int startYear,
    required int endYear,
  }) async {
    final climate = await NasaApiService.fetchClimate(governorate);
    final results = <TrendResult>[];

    for (final v in variables) {
      final s = climate.series[v.id];
      if (s == null) continue;
      final pts = s.points
          .where((p) => p.year >= startYear && p.year <= endYear)
          .toList();
      if (pts.length < AppConstants.minYears) continue;
      results.add(analyzePoints(v, pts));
    }

    final inv = InvestigationModel(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      governorate: governorate,
      results: results,
      impacts: buildImpacts(results),
      startYear: startYear,
      endYear: endYear,
      createdAt: DateTime.now(),
      isSample: climate.isSample,
    );
    history.insert(0, inv);
    return inv;
  }

  /// Trend analysis of an annual series.
  static TrendResult analyzePoints(EarthVariable v, List<AnnualPoint> pts) {
    final n = pts.length;
    final xs = pts.map((p) => p.year.toDouble()).toList();
    final ys = pts.map((p) => p.value).toList();

    // --- Mann-Kendall statistic S and Sen's slope ---
    var s = 0;
    final slopes = <double>[];
    for (var i = 0; i < n - 1; i++) {
      for (var j = i + 1; j < n; j++) {
        final d = ys[j] - ys[i];
        if (d > 0) {
          s++;
        } else if (d < 0) {
          s--;
        }
        slopes.add(d / (xs[j] - xs[i]));
      }
    }

    // Variance of S with tie correction.
    final ties = <double, int>{};
    for (final y in ys) {
      ties[y] = (ties[y] ?? 0) + 1;
    }
    var varS = n * (n - 1) * (2 * n + 5) / 18.0;
    ties.forEach((_, t) {
      if (t > 1) varS -= t * (t - 1) * (2 * t + 5) / 18.0;
    });

    double z = 0;
    if (varS > 0) {
      if (s > 0) {
        z = (s - 1) / sqrt(varS);
      } else if (s < 0) {
        z = (s + 1) / sqrt(varS);
      }
    }
    final p = 2 * (1 - _normCdf(z.abs()));
    final tau = s / (n * (n - 1) / 2.0);

    final slope = _median(slopes);
    final intercept =
        _median([for (var i = 0; i < n; i++) ys[i] - slope * xs[i]]);

    // --- R² of an ordinary least-squares line (goodness of fit) ---
    final mx = xs.reduce((a, b) => a + b) / n;
    final my = ys.reduce((a, b) => a + b) / n;
    var sxx = 0.0, syy = 0.0, sxy = 0.0;
    for (var i = 0; i < n; i++) {
      sxx += (xs[i] - mx) * (xs[i] - mx);
      syy += (ys[i] - my) * (ys[i] - my);
      sxy += (xs[i] - mx) * (ys[i] - my);
    }
    final r2 = (sxx > 0 && syy > 0) ? (sxy * sxy) / (sxx * syy) : 0.0;

    final startFit = intercept + slope * xs.first;
    final endFit = intercept + slope * xs.last;
    final total = endFit - startFit;
    final pct = startFit.abs() > 1e-9 ? total / startFit.abs() * 100 : 0.0;

    return TrendResult(
      variable: v,
      points: pts,
      startYear: pts.first.year,
      endYear: pts.last.year,
      mean: my,
      slopePerYear: slope,
      intercept: intercept,
      startFit: startFit,
      endFit: endFit,
      totalChange: total,
      percentChange: pct,
      tau: tau,
      zScore: z,
      pValue: p,
      rSquared: r2,
      significant: p < AppConstants.alpha,
    );
  }

  /// "What it affects": notes for every statistically significant change.
  static List<ImpactNote> buildImpacts(List<TrendResult> results) {
    final out = <ImpactNote>[];
    for (final r in results) {
      if (!r.significant) continue;
      final up = r.slopePerYear > 0;
      for (final rule in ImpactRules.forVariable(r.variable.id, up)) {
        out.add(ImpactNote(
          variableId: r.variable.id,
          increasing: up,
          sectorEn: rule.sectorEn,
          sectorAr: rule.sectorAr,
          textEn: rule.textEn,
          textAr: rule.textAr,
          icon: rule.icon,
        ));
      }
    }
    return out;
  }

  static double _median(List<double> values) {
    final a = List<double>.from(values)..sort();
    final m = a.length ~/ 2;
    return a.length.isOdd ? a[m] : (a[m - 1] + a[m]) / 2;
  }

  /// Standard normal CDF (Abramowitz & Stegun erf approximation).
  static double _normCdf(double x) {
    final z = x / sqrt2;
    final sign = z < 0 ? -1.0 : 1.0;
    final az = z.abs();
    const p = 0.3275911;
    const a1 = 0.254829592;
    const a2 = -0.284496736;
    const a3 = 1.421413741;
    const a4 = -1.453152027;
    const a5 = 1.061405429;
    final t = 1.0 / (1.0 + p * az);
    final y = 1.0 -
        (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * exp(-az * az);
    return 0.5 * (1.0 + sign * y);
  }
}
