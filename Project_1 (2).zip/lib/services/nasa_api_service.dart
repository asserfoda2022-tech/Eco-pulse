import 'dart:convert';
import 'dart:math';

import 'package:http/http.dart' as http;
import 'package:project_1/data/governorate_data.dart';
import 'package:project_1/models/earth_data_model.dart';
import 'package:project_1/utils/app_constants.dart';

/// Fetches monthly Earth-science data from the NASA POWER API
/// (https://power.larc.nasa.gov) and converts it to annual means.
///
/// If the network or the API is unavailable, deterministic SAMPLE data is
/// returned and flagged with `isSample = true` so the UI can tell the user.
class NasaApiService {
  NasaApiService._();

  static const String _base =
      'https://power.larc.nasa.gov/api/temporal/monthly/point';

  static final Map<String, GovernorateClimate> _cache =
      <String, GovernorateClimate>{};
  static DateTime? _lastFailure;

  static Future<GovernorateClimate> fetchClimate(
    Governorate g, {
    bool forceRefresh = false,
  }) async {
    if (!forceRefresh && _cache.containsKey(g.id)) return _cache[g.id]!;

    // After a failure, do not hammer the network for 2 minutes.
    final lf = _lastFailure;
    if (!forceRefresh &&
        lf != null &&
        DateTime.now().difference(lf) < const Duration(minutes: 2)) {
      return _sample(g);
    }

    try {
      final uri = Uri.parse(
        '$_base?parameters=${EarthVariables.paramList}'
        '&community=AG&longitude=${g.lon}&latitude=${g.lat}'
        '&start=${AppConstants.firstYear}&end=${AppConstants.lastYear}'
        '&format=JSON',
      );
      final res = await http.get(uri).timeout(const Duration(seconds: 25));
      if (res.statusCode != 200) {
        throw Exception('NASA POWER returned ${res.statusCode}');
      }

      final decoded = jsonDecode(res.body) as Map<String, dynamic>;
      final props = decoded['properties'] as Map<String, dynamic>;
      final params = props['parameter'] as Map<String, dynamic>;

      final series = <String, EarthSeries>{};
      for (final v in EarthVariables.all) {
        final raw = params[v.nasaParam];
        if (raw is! Map) continue;

        final byYear = <int, List<double>>{};
        raw.forEach((key, value) {
          final k = key.toString();
          if (k.length != 6) return; // skip malformed keys
          final year = int.tryParse(k.substring(0, 4));
          final month = int.tryParse(k.substring(4));
          if (year == null || month == null) return;
          if (month < 1 || month > 12) return; // month 13 = annual mean
          if (value is! num) return;
          if (value <= -990) return; // NASA fill value for missing data
          byYear
              .putIfAbsent(year, () => <double>[])
              .add(value.toDouble() * v.scale);
        });

        final years = byYear.keys.toList()..sort();
        final pts = <AnnualPoint>[];
        for (final y in years) {
          final vals = byYear[y]!;
          if (vals.length < 11) continue; // need (almost) a full year
          final mean = vals.reduce((a, b) => a + b) / vals.length;
          pts.add(AnnualPoint(y, mean));
        }
        if (pts.isNotEmpty) {
          series[v.id] = EarthSeries(variable: v, points: pts, isSample: false);
        }
      }
      if (series.isEmpty) throw Exception('Empty NASA response');

      final climate = GovernorateClimate(
        governorateId: g.id,
        series: series,
        isSample: false,
        fetchedAt: DateTime.now(),
      );
      _cache[g.id] = climate;
      _lastFailure = null;
      return climate;
    } catch (_) {
      _lastFailure = DateTime.now();
      return _sample(g);
    }
  }

  /// Loads many governorates, 4 requests at a time.
  static Future<Map<String, GovernorateClimate>> fetchMany(
    List<Governorate> list, {
    void Function(int done, int total)? onProgress,
  }) async {
    final out = <String, GovernorateClimate>{};
    var done = 0;
    for (var i = 0; i < list.length; i += 4) {
      final batch = list.sublist(i, min(i + 4, list.length));
      final res = await Future.wait(batch.map((g) => fetchClimate(g)));
      for (var j = 0; j < batch.length; j++) {
        out[batch[j].id] = res[j];
      }
      done += batch.length;
      if (onProgress != null) onProgress(done, list.length);
    }
    return out;
  }

  // ---------------------------------------------------------------------
  // Sample data (offline fallback)
  // ---------------------------------------------------------------------

  static GovernorateClimate _sample(Governorate g) {
    final series = <String, EarthSeries>{};
    for (final v in EarthVariables.all) {
      series[v.id] = EarthSeries(
        variable: v,
        points: _samplePoints(g, v),
        isSample: true,
      );
    }
    return GovernorateClimate(
      governorateId: g.id,
      series: series,
      isSample: true,
      fetchedAt: DateTime.now(),
    );
  }

  static List<AnnualPoint> _samplePoints(Governorate g, EarthVariable v) {
    final rng = Random(g.id.codeUnits.fold<int>(7, (a, b) => a * 31 + b) +
        v.id.codeUnits.fold<int>(3, (a, b) => a * 17 + b));
    final north = g.lat >= 31.0;
    final mid = g.lat >= 29.5;

    double base;
    double trend;
    double noise;
    switch (v.id) {
      case 'temperature':
        base = 27.0 - (g.lat - 24.0) * 0.8 - (north ? 1.0 : 0.0);
        trend = 0.035;
        noise = 0.7;
        break;
      case 'rainfall':
        base = north ? 0.9 : (mid ? 0.12 : 0.02);
        trend = -0.003;
        noise = north ? 0.25 : 0.05;
        break;
      case 'soil':
        base = north ? 42.0 : (mid ? 30.0 : 12.0);
        trend = -0.15;
        noise = 3.0;
        break;
      case 'humidity':
        base = north ? 68.0 : (mid ? 52.0 : 33.0);
        trend = -0.08;
        noise = 2.0;
        break;
      default:
        base = 3.2 + (north ? 0.6 : 0.0);
        trend = 0.006;
        noise = 0.2;
    }

    final pts = <AnnualPoint>[];
    for (var y = AppConstants.firstYear; y <= AppConstants.lastYear; y++) {
      var val = base +
          trend * (y - AppConstants.firstYear) +
          (rng.nextDouble() - 0.5) * 2 * noise;
      if (val < 0) val = 0;
      if ((v.id == 'soil' || v.id == 'humidity') && val > 100) val = 100;
      pts.add(AnnualPoint(y, val));
    }
    return pts;
  }
}
