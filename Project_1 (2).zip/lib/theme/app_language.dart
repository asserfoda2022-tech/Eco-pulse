import 'package:flutter/material.dart';

/// Simple bilingual (English / Arabic) support with no extra packages.
///
/// Usage inside any widget:  context.tr('Home', 'الرئيسية')
class AppLanguage {
  AppLanguage._();

  static final ValueNotifier<bool> isArabic = ValueNotifier<bool>(false);

  static void toggle() => isArabic.value = !isArabic.value;
  static void setArabic(bool value) => isArabic.value = value;
}

/// Rebuilds every widget that calls context.tr / context.isAr when the
/// language changes, without resetting the navigation stack.
class AppLanguageScope extends InheritedNotifier<ValueNotifier<bool>> {
  const AppLanguageScope({
    Key? key,
    required ValueNotifier<bool> notifier,
    required Widget child,
  }) : super(key: key, notifier: notifier, child: child);
}

extension AppLanguageContext on BuildContext {
  bool get isAr {
    final scope = dependOnInheritedWidgetOfExactType<AppLanguageScope>();
    return scope?.notifier?.value ?? false;
  }

  String tr(String en, String ar) => isAr ? ar : en;
}
