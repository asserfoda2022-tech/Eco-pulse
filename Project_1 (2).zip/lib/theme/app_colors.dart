import 'package:flutter/material.dart';

class AppColors {
  AppColors._();

  // Background (deep forest green)
  static const Color bgTop = Color(0xFF071D24);
  static const Color bgMid = Color(0xFF064B43);
  static const Color bgBottom = Color(0xFF055B60);

  static const LinearGradient background = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [bgTop, bgMid, bgBottom],
  );

  // Brand
  static const Color primary = Color(0xFF4ADE9A);
  static const Color primaryDark = Color(0xFF1F8F63);
  static const Color onPrimary = Color(0xFF06281B);

  // Glass surfaces
  static const Color card = Color(0x14FFFFFF);
  static const Color cardStrong = Color(0x24FFFFFF);
  static const Color cardBorder = Color(0x26FFFFFF);
  static const Color navBar = Color(0xF20B241B);

  // Text
  static const Color textPrimary = Colors.white;
  static const Color textSecondary = Color(0xB3FFFFFF);
  static const Color textMuted = Color(0x80FFFFFF);

  // Trend semantics (neutral: not "good" or "bad", only direction)
  static const Color rising = Color(0xFFFF8A65);
  static const Color falling = Color(0xFF64B5F6);
  static const Color stable = Color(0xFFB0BEC5);

  static const Color warning = Color(0xFFFFC857);
  static const Color error = Color(0xFFFF6B6B);
}
