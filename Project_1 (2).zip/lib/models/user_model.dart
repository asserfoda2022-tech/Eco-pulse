class UserModel {
  final String name;
  final String email;
  final bool isGuest;
  final DateTime joinedAt;

  const UserModel({
    required this.name,
    required this.email,
    required this.isGuest,
    required this.joinedAt,
  });

  String get initials {
    final parts = name.trim().split(RegExp(r'\s+'));
    if (parts.isEmpty || parts.first.isEmpty) return '?';
    if (parts.length == 1) return parts.first.substring(0, 1).toUpperCase();
    return (parts.first.substring(0, 1) + parts.last.substring(0, 1))
        .toUpperCase();
  }
}
