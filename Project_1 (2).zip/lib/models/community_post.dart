import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

/// Type of environmental phenomenon a user can report.
class PhenomenonType {
  final String id;
  final String en;
  final String ar;
  final IconData icon;
  const PhenomenonType(this.id, this.en, this.ar, this.icon);

  String name(bool isAr) => isAr ? ar : en;

  static const List<PhenomenonType> all = [
    PhenomenonType(
        'heat_wave', 'Heat wave', 'موجة حر', Icons.wb_sunny_outlined),
    PhenomenonType(
        'heavy_rain', 'Heavy rain', 'أمطار غزيرة', Icons.water_drop_outlined),
    PhenomenonType('flood', 'Flood', 'سيول / فيضان', Icons.flood_outlined),
    PhenomenonType('drought', 'Drought', 'جفاف', Icons.landscape_outlined),
    PhenomenonType(
        'dust_storm', 'Dust storm', 'عاصفة ترابية', Icons.air_rounded),
    PhenomenonType(
        'air_pollution', 'Air pollution', 'تلوث الهواء', Icons.cloud_outlined),
    PhenomenonType('water_pollution', 'Water pollution', 'تلوث المياه',
        Icons.water_outlined),
    PhenomenonType('fog', 'Fog', 'شبورة', Icons.foggy),
    PhenomenonType('waste', 'Waste / burning', 'مخلفات / حرق',
        Icons.local_fire_department_outlined),
    PhenomenonType('other', 'Other', 'أخرى', Icons.eco_outlined),
  ];

  static PhenomenonType byId(String id) =>
      all.firstWhere((p) => p.id == id, orElse: () => all.last);
}

class CommunityPost {
  final String id;
  final String userId;
  final String authorName;
  final String governorateId;
  final String phenomenonId;
  final String description;
  final String? imageUrl;
  final DateTime? createdAt;

  const CommunityPost({
    required this.id,
    required this.userId,
    required this.authorName,
    required this.governorateId,
    required this.phenomenonId,
    required this.description,
    this.imageUrl,
    this.createdAt,
  });

  factory CommunityPost.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data() ?? <String, dynamic>{};
    final ts = d['createdAt'];
    return CommunityPost(
      id: doc.id,
      userId: (d['userId'] ?? '') as String,
      authorName: (d['authorName'] ?? '') as String,
      governorateId: (d['governorateId'] ?? '') as String,
      phenomenonId: (d['phenomenonId'] ?? 'other') as String,
      description: (d['description'] ?? '') as String,
      imageUrl: d['imageUrl'] as String?,
      // createdAt is null for a moment on the device that just wrote it.
      createdAt: ts is Timestamp ? ts.toDate() : null,
    );
  }
}
