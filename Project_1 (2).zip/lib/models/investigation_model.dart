import 'package:flutter/material.dart';
import 'package:project_1/data/governorate_data.dart';
import 'package:project_1/models/earth_data_model.dart';

enum TrendDirection { increasing, decreasing, stable }

/// Result of the statistical trend analysis of one variable.
class TrendResult {
  final EarthVariable variable;
  final List<AnnualPoint> points;
  final int startYear;
  final int endYear;

  final double mean;
  final double slopePerYear; // Sen's slope
  final double intercept;
  final double startFit; // fitted value at start year
  final double endFit; // fitted value at end year
  final double totalChange; // endFit - startFit
  final double percentChange;
  final double tau; // Kendall's tau
  final double zScore; // Mann-Kendall Z
  final double pValue;
  final double rSquared;
  final bool significant;

  const TrendResult({
    required this.variable,
    required this.points,
    required this.startYear,
    required this.endYear,
    required this.mean,
    required this.slopePerYear,
    required this.intercept,
    required this.startFit,
    required this.endFit,
    required this.totalChange,
    required this.percentChange,
    required this.tau,
    required this.zScore,
    required this.pValue,
    required this.rSquared,
    required this.significant,
  });

  double get slopePerDecade => slopePerYear * 10;

  TrendDirection get direction {
    if (slopePerYear.abs() < 1e-9) return TrendDirection.stable;
    return slopePerYear > 0
        ? TrendDirection.increasing
        : TrendDirection.decreasing;
  }
}

/// A short explanation of what a significant change may affect.
class ImpactNote {
  final String variableId;
  final bool increasing;
  final String sectorEn;
  final String sectorAr;
  final String textEn;
  final String textAr;
  final IconData icon;

  const ImpactNote({
    required this.variableId,
    required this.increasing,
    required this.sectorEn,
    required this.sectorAr,
    required this.textEn,
    required this.textAr,
    required this.icon,
  });

  String sector(bool ar) => ar ? sectorAr : sectorEn;
  String text(bool ar) => ar ? textAr : textEn;
}

/// One complete investigation: a governorate + selected variables + period.
class InvestigationModel {
  final String id;
  final Governorate governorate;
  final List<TrendResult> results;
  final List<ImpactNote> impacts;
  final int startYear;
  final int endYear;
  final DateTime createdAt;
  final bool isSample;

  const InvestigationModel({
    required this.id,
    required this.governorate,
    required this.results,
    required this.impacts,
    required this.startYear,
    required this.endYear,
    required this.createdAt,
    required this.isSample,
  });

  List<TrendResult> get significantResults =>
      results.where((r) => r.significant).toList();
}
