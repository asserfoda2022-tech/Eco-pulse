import 'package:flutter/material.dart';

/// One Earth-science variable (measured or modelled by NASA).
class EarthVariable {
  final String id;
  final String nasaParam; // NASA POWER parameter code
  final String nameEn;
  final String nameAr;
  final String unit;
  final IconData icon;
  final int decimals;
  final double scale; // multiplier applied to the raw NASA value
  final String descEn;
  final String descAr;

  const EarthVariable({
    required this.id,
    required this.nasaParam,
    required this.nameEn,
    required this.nameAr,
    required this.unit,
    required this.icon,
    required this.decimals,
    required this.scale,
    required this.descEn,
    required this.descAr,
  });

  String name(bool ar) => ar ? nameAr : nameEn;
  String description(bool ar) => ar ? descAr : descEn;
}

class EarthVariables {
  EarthVariables._();

  static const EarthVariable temperature = EarthVariable(
    id: 'temperature',
    nasaParam: 'T2M',
    nameEn: 'Temperature',
    nameAr: 'درجة الحرارة',
    unit: '°C',
    icon: Icons.thermostat,
    decimals: 1,
    scale: 1,
    descEn: 'Mean air temperature at 2 m above the ground (NASA MERRA-2).',
    descAr:
        'متوسط درجة حرارة الهواء على ارتفاع ٢ متر فوق سطح الأرض (ناسا MERRA-2).',
  );

  static const EarthVariable rainfall = EarthVariable(
    id: 'rainfall',
    nasaParam: 'PRECTOTCORR',
    nameEn: 'Rainfall',
    nameAr: 'الأمطار',
    unit: 'mm/day',
    icon: Icons.water_drop_outlined,
    decimals: 2,
    scale: 1,
    descEn: 'Bias-corrected precipitation (NASA MERRA-2 / IMERG).',
    descAr: 'كمية الهطول بعد تصحيح الانحياز (ناسا MERRA-2 / IMERG).',
  );

  static const EarthVariable soilMoisture = EarthVariable(
    id: 'soil',
    nasaParam: 'GWETROOT',
    nameEn: 'Soil Moisture',
    nameAr: 'رطوبة التربة',
    unit: '%',
    icon: Icons.grass,
    decimals: 1,
    scale: 100,
    descEn: 'Root-zone soil wetness (0-100%) from NASA GEOS / MERRA-2.',
    descAr: 'رطوبة منطقة الجذور في التربة (٠-١٠٠٪) من نماذج ناسا.',
  );

  static const EarthVariable humidity = EarthVariable(
    id: 'humidity',
    nasaParam: 'RH2M',
    nameEn: 'Humidity',
    nameAr: 'الرطوبة النسبية',
    unit: '%',
    icon: Icons.opacity,
    decimals: 1,
    scale: 1,
    descEn: 'Relative humidity of the air at 2 m (NASA MERRA-2).',
    descAr: 'الرطوبة النسبية للهواء على ارتفاع ٢ متر (ناسا MERRA-2).',
  );

  static const EarthVariable wind = EarthVariable(
    id: 'wind',
    nasaParam: 'WS2M',
    nameEn: 'Wind Speed',
    nameAr: 'سرعة الرياح',
    unit: 'm/s',
    icon: Icons.air,
    decimals: 2,
    scale: 1,
    descEn: 'Wind speed at 2 m above the ground (NASA MERRA-2).',
    descAr: 'سرعة الرياح على ارتفاع ٢ متر فوق سطح الأرض (ناسا MERRA-2).',
  );

  static const List<EarthVariable> all = [
    temperature,
    rainfall,
    soilMoisture,
    humidity,
    wind,
  ];

  static String get paramList => all.map((v) => v.nasaParam).join(',');

  static EarthVariable byId(String id) =>
      all.firstWhere((v) => v.id == id, orElse: () => all.first);
}

/// Annual mean value of a variable.
class AnnualPoint {
  final int year;
  final double value;
  const AnnualPoint(this.year, this.value);
}

class EarthSeries {
  final EarthVariable variable;
  final List<AnnualPoint> points;
  final bool isSample;

  const EarthSeries({
    required this.variable,
    required this.points,
    required this.isSample,
  });

  double? get latest => points.isEmpty ? null : points.last.value;
}

/// All variables for one governorate.
class GovernorateClimate {
  final String governorateId;
  final Map<String, EarthSeries> series;
  final bool isSample;
  final DateTime fetchedAt;

  const GovernorateClimate({
    required this.governorateId,
    required this.series,
    required this.isSample,
    required this.fetchedAt,
  });
}
