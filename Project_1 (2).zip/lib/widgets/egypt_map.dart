import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:project_1/data/governorate_data.dart';
import 'package:project_1/theme/app_colors.dart';
import 'package:project_1/theme/app_language.dart';

/// Interactive street map of Egypt. Users can pan/zoom, choose any
/// governorate from the locator, or tap its marker to zoom directly to it.
class EgyptMap extends StatefulWidget {
  final List<Governorate> governorates;
  final Governorate? selected;
  final Color Function(Governorate g) colorOf;
  final ValueChanged<Governorate> onSelected;
  final double height;

  const EgyptMap({
    super.key,
    required this.governorates,
    required this.onSelected,
    required this.colorOf,
    this.selected,
    this.height = 380,
  });

  @override
  State<EgyptMap> createState() => _EgyptMapState();
}

class _EgyptMapState extends State<EgyptMap> {
  static const double _minZoom = 4.0;
  static const double _maxZoom = 15.0;
  static const double _labelZoom = 6.2;

  static final LatLngBounds _egyptBounds =
      LatLngBounds(const LatLng(21.7, 24.4), const LatLng(32.0, 37.0));

  final MapController _controller = MapController();
  bool _showLabels = false;
  bool _showGovernorateMarkers = false;
  bool _mapReady = false;

  CameraFit _fitEgypt() => CameraFit.bounds(
        bounds: _egyptBounds,
        padding: const EdgeInsets.fromLTRB(28, 52, 28, 28),
      );

  @override
  void didUpdateWidget(covariant EgyptMap oldWidget) {
    super.didUpdateWidget(oldWidget);
    final oldId = oldWidget.selected?.id;
    final newId = widget.selected?.id;
    if (_mapReady && newId != null && newId != oldId) {
      _focusOn(widget.selected!);
    }
  }

  void _zoomBy(double delta) {
    if (!_mapReady) return;
    final camera = _controller.camera;
    final zoom = (camera.zoom + delta).clamp(_minZoom, _maxZoom).toDouble();
    _controller.move(camera.center, zoom);
  }

  void _focusOn(Governorate governorate) {
    if (!_mapReady) return;
    final currentZoom = _controller.camera.zoom;
    final zoom =
        math.max(currentZoom, 9.0).clamp(_minZoom, _maxZoom).toDouble();
    _controller.move(LatLng(governorate.lat, governorate.lon), zoom);
  }

  void _selectGovernorate(Governorate governorate) {
    widget.onSelected(governorate);
    _focusOn(governorate);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ar = context.isAr;

    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: Container(
        height: widget.height,
        decoration: BoxDecoration(
          color: AppColors.bgBottom,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppColors.cardBorder),
        ),
        child: Stack(
          children: [
            FlutterMap(
              mapController: _controller,
              options: MapOptions(
                initialCameraFit: _fitEgypt(),
                minZoom: _minZoom,
                maxZoom: _maxZoom,
                backgroundColor: AppColors.bgBottom,
                interactionOptions: const InteractionOptions(
                  flags: InteractiveFlag.all & ~InteractiveFlag.rotate,
                ),
                onMapReady: () {
                  _mapReady = true;
                  if (widget.selected != null) _focusOn(widget.selected!);
                },
                onPositionChanged: (camera, hasGesture) {
                  final show = camera.zoom >= _labelZoom;
                  final showMarkers = camera.zoom >= 5.2;
                  if ((show != _showLabels ||
                          showMarkers != _showGovernorateMarkers) &&
                      mounted) {
                    setState(() {
                      _showLabels = show;
                      _showGovernorateMarkers = showMarkers;
                    });
                  }
                },
              ),
              children: [
                // Live cartographic basemap with roads, towns, coastlines,
                // and place labels rather than a decorative/static image.
                TileLayer(
                  // OpenStreetMap Standard tiles: clear roads, borders,
                  // towns and place names, similar to a conventional map app.
                  urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                  userAgentPackageName: 'com.example.project_1',
                  maxNativeZoom: 19,
                ),
                MarkerLayer(markers: _markers(ar)),
                const SimpleAttributionWidget(
                  source: Text('© OpenStreetMap contributors'),
                  backgroundColor: Color(0xEFFFFFFF),
                ),
              ],
            ),
            Positioned(
              left: 10,
              top: 10,
              child: PopupMenuButton<Governorate>(
                tooltip: context.tr('Find a governorate', 'اختار محافظتك'),
                onSelected: _selectGovernorate,
                color: Colors.white,
                constraints:
                    const BoxConstraints(maxHeight: 420, minWidth: 190),
                itemBuilder: (context) => widget.governorates
                    .map((g) => PopupMenuItem<Governorate>(
                          value: g,
                          child: Row(
                            children: [
                              Icon(
                                Icons.location_on_outlined,
                                size: 17,
                                color: g.id == widget.selected?.id
                                    ? AppColors.primaryDark
                                    : Colors.blueGrey,
                              ),
                              const SizedBox(width: 8),
                              Text(
                                g.name(ar),
                                style: TextStyle(
                                  color: const Color(0xFF263238),
                                  fontSize: 13,
                                  fontWeight: g.id == widget.selected?.id
                                      ? FontWeight.w700
                                      : FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ))
                    .toList(),
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 11, vertical: 9),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.97),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: const Color(0xFFE0E5E8)),
                    boxShadow: const [
                      BoxShadow(
                          color: Color(0x26000000),
                          blurRadius: 8,
                          offset: Offset(0, 2)),
                    ],
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.search,
                          size: 17, color: AppColors.primaryDark),
                      const SizedBox(width: 6),
                      Text(
                        widget.selected == null
                            ? context.tr('Find governorate', 'ابحث عن محافظة')
                            : widget.selected!.name(ar),
                        style: const TextStyle(
                          color: Color(0xFF263238),
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(width: 4),
                      const Icon(Icons.keyboard_arrow_down,
                          size: 17, color: Color(0xFF607D8B)),
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              right: 10,
              top: 10,
              child: Column(
                children: [
                  _MapButton(icon: Icons.add, onTap: () => _zoomBy(1)),
                  const SizedBox(height: 8),
                  _MapButton(icon: Icons.remove, onTap: () => _zoomBy(-1)),
                  const SizedBox(height: 8),
                  _MapButton(
                    icon: Icons.public,
                    onTap: () {
                      if (_mapReady) _controller.fitCamera(_fitEgypt());
                    },
                  ),
                ],
              ),
            ),
            if (!_mapReady)
              const Center(
                child: CircularProgressIndicator(color: AppColors.primary),
              ),
          ],
        ),
      ),
    );
  }

  List<Marker> _markers(bool ar) {
    final ordered = [...widget.governorates]..sort((a, b) {
        final aSelected = a.id == widget.selected?.id ? 1 : 0;
        final bSelected = b.id == widget.selected?.id ? 1 : 0;
        return aSelected.compareTo(bSelected);
      });

    final visibleGovernorates = ordered
        .where((g) => _showGovernorateMarkers || g.id == widget.selected?.id);

    return visibleGovernorates.map((g) {
      final isSelected = g.id == widget.selected?.id;
      final color = widget.colorOf(g);
      final dotSize = isSelected ? 22.0 : 15.0;
      return Marker(
        point: LatLng(g.lat, g.lon),
        width: 42,
        height: 42,
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () => _selectGovernorate(g),
          child: Stack(
            alignment: Alignment.center,
            clipBehavior: Clip.none,
            children: [
              if (isSelected)
                Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: color.withOpacity(0.22),
                  ),
                ),
              AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                width: dotSize,
                height: dotSize,
                decoration: BoxDecoration(
                  color: color,
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: Colors.white,
                    width: isSelected ? 2.8 : 1.4,
                  ),
                  boxShadow: const [
                    BoxShadow(color: Colors.black54, blurRadius: 5),
                  ],
                ),
              ),
              if (_showLabels || isSelected)
                Positioned(
                  top: 32,
                  left: -42,
                  right: -42,
                  child: Center(
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 3),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(7),
                        border: Border.all(
                          color: isSelected
                              ? AppColors.primaryDark
                              : const Color(0xFFDCE3E7),
                        ),
                        boxShadow: const [
                          BoxShadow(
                              color: Color(0x26000000),
                              blurRadius: 5,
                              offset: Offset(0, 1)),
                        ],
                      ),
                      child: Text(
                        g.name(ar),
                        maxLines: 1,
                        softWrap: false,
                        overflow: TextOverflow.visible,
                        style: const TextStyle(
                          color: Color(0xFF263238),
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      );
    }).toList();
  }
}

class _MapButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _MapButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      elevation: 2,
      shape: const CircleBorder(side: BorderSide(color: Color(0xFFE0E5E8))),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: SizedBox(
          width: 38,
          height: 38,
          child: Icon(icon, color: const Color(0xFF37474F), size: 20),
        ),
      ),
    );
  }
}
