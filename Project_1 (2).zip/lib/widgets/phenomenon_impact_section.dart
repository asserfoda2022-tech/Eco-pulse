import 'package:flutter/material.dart';
import 'package:project_1/data/governorate_data.dart';
import 'package:project_1/data/phenomena_impact_data.dart';
import 'package:project_1/models/earth_data_model.dart';
import 'package:project_1/theme/app_colors.dart';
import 'package:project_1/theme/app_language.dart';
import 'package:project_1/theme/app_text_styles.dart';
import 'package:project_1/widgets/custom_card.dart';

/// Explains the impact of each phenomenon and highlights relevance to the
/// governorate currently selected on the Explore map.
class PhenomenonImpactSection extends StatelessWidget {
  final String? highlightId;
  final Governorate? selectedGovernorate;

  const PhenomenonImpactSection({
    super.key,
    this.highlightId,
    this.selectedGovernorate,
  });

  @override
  Widget build(BuildContext context) {
    final ar = context.isAr;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SectionTitle(context.tr(
            'How each phenomenon affects Egypt', 'تأثير كل ظاهرة على مصر')),
        if (selectedGovernorate != null)
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
            child: Text(
              context.tr(
                'Impact relevance for ${selectedGovernorate!.name(false)}',
                'مدى ارتباط التأثير بمحافظة ${selectedGovernorate!.name(true)}',
              ),
              style: AppTextStyles.caption,
            ),
          ),
        for (final phenomenon in PhenomenaImpactData.all)
          _ImpactCard(
            impact: phenomenon,
            ar: ar,
            highlighted: phenomenon.variableId == highlightId,
            selectedGovernorate: selectedGovernorate,
          ),
      ],
    );
  }
}

class _ImpactCard extends StatelessWidget {
  final PhenomenonImpact impact;
  final bool ar;
  final bool highlighted;
  final Governorate? selectedGovernorate;

  const _ImpactCard({
    required this.impact,
    required this.ar,
    required this.highlighted,
    required this.selectedGovernorate,
  });

  @override
  Widget build(BuildContext context) {
    final variable = EarthVariables.byId(impact.variableId);
    final isRelevant = selectedGovernorate != null &&
        impact.exposedGovernorateIds.contains(selectedGovernorate!.id);

    return Container(
      margin: const EdgeInsets.fromLTRB(20, 0, 20, 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: highlighted ? AppColors.primary : Colors.transparent,
          width: 1.4,
        ),
      ),
      child: GlassCard(
        margin: EdgeInsets.zero,
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: AppColors.primary.withOpacity(0.16),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child:
                      Icon(variable.icon, color: AppColors.primary, size: 22),
                ),
                const SizedBox(width: 12),
                Expanded(
                    child: Text(variable.name(ar), style: AppTextStyles.h2)),
                if (highlighted)
                  const Icon(Icons.check_circle,
                      color: AppColors.primary, size: 19),
              ],
            ),
            if (selectedGovernorate != null) ...[
              const SizedBox(height: 10),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                decoration: BoxDecoration(
                  color: (isRelevant ? AppColors.warning : AppColors.textMuted)
                      .withOpacity(0.10),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  children: [
                    Icon(
                      isRelevant ? Icons.location_on : Icons.info_outline,
                      size: 15,
                      color:
                          isRelevant ? AppColors.warning : AppColors.textMuted,
                    ),
                    const SizedBox(width: 7),
                    Expanded(
                      child: Text(
                        isRelevant
                            ? context.tr(
                                'This phenomenon is especially relevant to ${selectedGovernorate!.name(false)}.',
                                'الظاهرة دي من التأثيرات المهمة في محافظة ${selectedGovernorate!.name(true)}.',
                              )
                            : context.tr(
                                'General Egypt-wide impact; not listed among the main exposed areas.',
                                'تأثير عام على مصر، والمحافظة مش ضمن المناطق الأكثر تعرضاً المذكورة.',
                              ),
                        style: AppTextStyles.caption,
                      ),
                    ),
                  ],
                ),
              ),
            ],
            const SizedBox(height: 12),
            Text(impact.summary(ar), style: AppTextStyles.body),
            const SizedBox(height: 12),
            for (final line in impact.impacts(ar))
              Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Padding(
                      padding: EdgeInsets.only(top: 6),
                      child:
                          Icon(Icons.circle, size: 6, color: AppColors.primary),
                    ),
                    const SizedBox(width: 10),
                    Expanded(child: Text(line, style: AppTextStyles.body)),
                  ],
                ),
              ),
            const SizedBox(height: 6),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppColors.warning.withOpacity(0.10),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.place_outlined,
                      size: 16, color: AppColors.warning),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      impact.areas(ar),
                      style: AppTextStyles.caption
                          .copyWith(color: AppColors.textSecondary),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
