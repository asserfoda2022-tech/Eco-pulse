import 'package:flutter/material.dart';
import 'package:project_1/theme/app_colors.dart';
import 'package:project_1/theme/app_text_styles.dart';

class CustomButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final bool loading;
  final bool outlined;

  const CustomButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.loading = false,
    this.outlined = false,
  });

  @override
  Widget build(BuildContext context) {
    final enabled = onPressed != null && !loading;
    final fg = outlined ? AppColors.primary : AppColors.onPrimary;

    return SizedBox(
      width: double.infinity,
      height: 52,
      child: Material(
        color: outlined ? Colors.transparent : AppColors.primary,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: outlined
              ? const BorderSide(color: AppColors.primary, width: 1.4)
              : BorderSide.none,
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: enabled ? onPressed : null,
          child: Opacity(
            opacity: onPressed == null ? 0.5 : 1,
            child: Center(
              child: loading
                  ? SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(
                        strokeWidth: 2.4,
                        color: fg,
                      ),
                    )
                  : Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (icon != null) ...[
                          Icon(icon, color: fg, size: 20),
                          const SizedBox(width: 8),
                        ],
                        Text(label,
                            style: AppTextStyles.button.copyWith(color: fg)),
                      ],
                    ),
            ),
          ),
        ),
      ),
    );
  }
}
