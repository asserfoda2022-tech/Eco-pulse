import 'package:flutter/material.dart';
import 'package:project_1/data/governorate_data.dart';
import 'package:project_1/theme/app_colors.dart';
import 'package:project_1/theme/app_language.dart';
import 'package:project_1/theme/app_text_styles.dart';

/// Dropdown to pick one of the 27 governorates of Egypt.
class LocationSelector extends StatelessWidget {
  final Governorate selected;
  final ValueChanged<Governorate> onChanged;

  const LocationSelector({
    super.key,
    required this.selected,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final ar = context.isAr;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.symmetric(horizontal: 16),
      height: 56,
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: Row(
        children: [
          const Icon(Icons.location_on_outlined,
              color: AppColors.primary, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: selected.id,
                isExpanded: true,
                dropdownColor: const Color(0xFF14382D),
                borderRadius: BorderRadius.circular(16),
                menuMaxHeight: 380,
                icon: const Icon(Icons.keyboard_arrow_down_rounded,
                    color: AppColors.textSecondary),
                style: AppTextStyles.h3,
                items: GovernorateData.all
                    .map(
                      (g) => DropdownMenuItem<String>(
                        value: g.id,
                        child: Text(g.name(ar)),
                      ),
                    )
                    .toList(),
                onChanged: (id) {
                  if (id != null) onChanged(GovernorateData.byId(id));
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
