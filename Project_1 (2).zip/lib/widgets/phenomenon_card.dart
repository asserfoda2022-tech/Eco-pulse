import 'package:flutter/material.dart';
import 'package:project_1/models/earth_data_model.dart';
import 'package:project_1/models/investigation_model.dart';
import 'package:project_1/theme/app_colors.dart';
import 'package:project_1/theme/app_language.dart';
import 'package:project_1/theme/app_text_styles.dart';
import 'package:project_1/utils/app_helpers.dart';
import 'package:project_1/widgets/custom_card.dart';

/// Square tile of the home screen: icon + name + latest value.
class PhenomenonCard extends StatelessWidget {
  final EarthVariable variable;
  final String value; // already formatted, e.g. "29.5 °C"
  final VoidCallback? onTap;

  const PhenomenonCard({
    super.key,
    required this.variable,
    required this.value,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      onTap: onTap,
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Icon(variable.icon, color: AppColors.primary, size: 20),
          Text(
            variable.name(context.isAr),
            style: AppTextStyles.label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: AlignmentDirectional.centerStart,
            child: Text(value, style: AppTextStyles.value),
          ),
        ],
      ),
    );
  }
}

/// "Significant" / "Not significant" pill.
class SignificanceChip extends StatelessWidget {
  final bool significant;
  const SignificanceChip({super.key, required this.significant});

  @override
  Widget build(BuildContext context) {
    final color = significant ? AppColors.primary : AppColors.stable;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        significant
            ? context.tr('Significant', 'معنوي')
            : context.tr('Not significant', 'غير معنوي'),
        style:
            TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: color),
      ),
    );
  }
}

/// Row card that summarises the trend of one variable.
class TrendTile extends StatelessWidget {
  final TrendResult result;
  final VoidCallback? onTap;
  final String? title; // overrides the variable name (e.g. governorate name)
  final String? subtitle;

  const TrendTile({
    super.key,
    required this.result,
    this.onTap,
    this.title,
    this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    final v = result.variable;
    final color = AppHelpers.trendColor(result);
    final change = AppHelpers.fmtSigned(
        result.slopePerDecade, AppHelpers.changeDecimals(v.decimals));

    return GlassCard(
      margin: const EdgeInsets.fromLTRB(20, 0, 20, 10),
      onTap: onTap,
      padding: const EdgeInsets.all(14),
      child: Row(
        children: [
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: color.withOpacity(0.16),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(AppHelpers.trendIcon(result), color: color),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title ?? v.name(context.isAr), style: AppTextStyles.h3),
                const SizedBox(height: 3),
                Text(
                  subtitle ??
                      '$change ${v.unit} ${context.tr('per decade', 'لكل عقد')}',
                  style: AppTextStyles.body.copyWith(color: color),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              SignificanceChip(significant: result.significant),
              const SizedBox(height: 6),
              Text(
                'p = ${AppHelpers.fmtP(result.pValue)}',
                style: AppTextStyles.caption,
              ),
            ],
          ),
        ],
      ),
    );
  }
}
