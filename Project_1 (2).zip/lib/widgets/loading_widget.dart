import 'package:flutter/material.dart';
import 'package:project_1/theme/app_colors.dart';
import 'package:project_1/theme/app_text_styles.dart';

class LoadingWidget extends StatelessWidget {
  final String? message;
  final double? progress; // 0..1, null = indeterminate

  const LoadingWidget({super.key, this.message, this.progress});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: 46,
            height: 46,
            child: CircularProgressIndicator(
              value: progress,
              strokeWidth: 3,
              color: AppColors.primary,
              backgroundColor: AppColors.cardBorder,
            ),
          ),
          if (message != null) ...[
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 32),
              child: Text(
                message!,
                textAlign: TextAlign.center,
                style: AppTextStyles.body,
              ),
            ),
          ],
        ],
      ),
    );
  }
}

/// Full-screen dimmed overlay with a loader (used while analysing).
class LoadingOverlay extends StatelessWidget {
  final String message;
  const LoadingOverlay({super.key, required this.message});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.bgBottom.withOpacity(0.82),
      child: LoadingWidget(message: message),
    );
  }
}
