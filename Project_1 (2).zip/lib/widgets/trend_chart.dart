import 'package:flutter/material.dart';
import 'package:project_1/models/earth_data_model.dart';
import 'package:project_1/theme/app_colors.dart';

/// Line chart of annual values with the Sen's-slope trend line.
/// Touch / drag on the chart to read the value of each year.
class TrendChart extends StatefulWidget {
  final List<AnnualPoint> points;
  final double slope;
  final double intercept;
  final Color color;
  final String unit;
  final int decimals;
  final double height;

  const TrendChart({
    super.key,
    required this.points,
    required this.slope,
    required this.intercept,
    required this.color,
    required this.unit,
    required this.decimals,
    this.height = 240,
  });

  @override
  State<TrendChart> createState() => _TrendChartState();
}

class _TrendChartState extends State<TrendChart> {
  int? _hover;

  void _updateHover(double dx, double width) {
    final pts = widget.points;
    if (pts.length < 2) return;
    const left = _ChartPainter.padLeft;
    const right = _ChartPainter.padRight;
    final w = width - left - right;
    final t = ((dx - left) / w).clamp(0.0, 1.0);
    final idx = (t * (pts.length - 1)).round();
    if (idx != _hover) setState(() => _hover = idx);
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, c) {
        final width = c.maxWidth;
        return GestureDetector(
          onTapDown: (d) => _updateHover(d.localPosition.dx, width),
          onPanStart: (d) => _updateHover(d.localPosition.dx, width),
          onPanUpdate: (d) => _updateHover(d.localPosition.dx, width),
          child: CustomPaint(
            size: Size(width, widget.height),
            painter: _ChartPainter(
              points: widget.points,
              slope: widget.slope,
              intercept: widget.intercept,
              color: widget.color,
              unit: widget.unit,
              decimals: widget.decimals,
              hover: _hover,
            ),
          ),
        );
      },
    );
  }
}

class _ChartPainter extends CustomPainter {
  static const double padLeft = 44;
  static const double padRight = 14;
  static const double padTop = 28;
  static const double padBottom = 26;

  final List<AnnualPoint> points;
  final double slope;
  final double intercept;
  final Color color;
  final String unit;
  final int decimals;
  final int? hover;

  _ChartPainter({
    required this.points,
    required this.slope,
    required this.intercept,
    required this.color,
    required this.unit,
    required this.decimals,
    required this.hover,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (points.length < 2) return;

    final w = size.width - padLeft - padRight;
    final h = size.height - padTop - padBottom;

    final minYear = points.first.year.toDouble();
    final maxYear = points.last.year.toDouble();

    // Value range (include trend line ends).
    var minV = points.map((p) => p.value).reduce((a, b) => a < b ? a : b);
    var maxV = points.map((p) => p.value).reduce((a, b) => a > b ? a : b);
    final t1 = intercept + slope * minYear;
    final t2 = intercept + slope * maxYear;
    for (final t in [t1, t2]) {
      if (t < minV) minV = t;
      if (t > maxV) maxV = t;
    }
    var span = maxV - minV;
    if (span < 1e-9) span = 1;
    minV -= span * 0.12;
    maxV += span * 0.12;
    span = maxV - minV;

    double xOf(double year) =>
        padLeft + (year - minYear) / (maxYear - minYear) * w;
    double yOf(double v) => padTop + (1 - (v - minV) / span) * h;

    // Grid + y labels.
    final gridPaint = Paint()
      ..color = AppColors.cardBorder
      ..strokeWidth = 1;
    for (var i = 0; i <= 4; i++) {
      final v = minV + span * i / 4;
      final y = yOf(v);
      canvas.drawLine(Offset(padLeft, y), Offset(padLeft + w, y), gridPaint);
      _text(canvas, v.toStringAsFixed(decimals), Offset(padLeft - 6, y),
          const TextStyle(fontSize: 10, color: AppColors.textMuted),
          alignRight: true, centerY: true);
    }

    // X labels (first, middle, last).
    final mid = ((minYear + maxYear) / 2).round();
    for (final yr in [points.first.year, mid, points.last.year]) {
      _text(
          canvas,
          '$yr',
          Offset(xOf(yr.toDouble()), size.height - padBottom + 6),
          const TextStyle(fontSize: 10, color: AppColors.textMuted),
          centerX: true);
    }

    // Area under the line.
    final linePath = Path();
    for (var i = 0; i < points.length; i++) {
      final p = points[i];
      final o = Offset(xOf(p.year.toDouble()), yOf(p.value));
      if (i == 0) {
        linePath.moveTo(o.dx, o.dy);
      } else {
        linePath.lineTo(o.dx, o.dy);
      }
    }
    final area = Path.from(linePath)
      ..lineTo(xOf(maxYear), padTop + h)
      ..lineTo(xOf(minYear), padTop + h)
      ..close();
    canvas.drawPath(
      area,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [color.withOpacity(0.28), color.withOpacity(0.0)],
        ).createShader(Rect.fromLTWH(padLeft, padTop, w, h)),
    );

    // Data line.
    canvas.drawPath(
      linePath,
      Paint()
        ..color = color
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.4
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round,
    );

    // Dashed trend line.
    _dashed(
      canvas,
      Offset(xOf(minYear), yOf(t1)),
      Offset(xOf(maxYear), yOf(t2)),
      Paint()
        ..color = Colors.white
        ..strokeWidth = 1.8,
    );

    // Hover marker.
    final hv = hover;
    if (hv != null && hv >= 0 && hv < points.length) {
      final p = points[hv];
      final o = Offset(xOf(p.year.toDouble()), yOf(p.value));
      canvas.drawLine(
        Offset(o.dx, padTop),
        Offset(o.dx, padTop + h),
        Paint()
          ..color = Colors.white.withOpacity(0.35)
          ..strokeWidth = 1,
      );
      canvas.drawCircle(o, 6, Paint()..color = AppColors.bgBottom);
      canvas.drawCircle(o, 4.5, Paint()..color = color);

      final label = '${p.year}: ${p.value.toStringAsFixed(decimals)} $unit';
      final tp = TextPainter(
        text: TextSpan(
          text: label,
          style: const TextStyle(
              fontSize: 11, fontWeight: FontWeight.w700, color: Colors.white),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      var bx = o.dx - tp.width / 2 - 8;
      if (bx < 4) bx = 4;
      if (bx + tp.width + 16 > size.width - 4) {
        bx = size.width - 4 - tp.width - 16;
      }
      final rect = RRect.fromRectAndRadius(
        Rect.fromLTWH(bx, 2, tp.width + 16, 22),
        const Radius.circular(8),
      );
      canvas.drawRRect(rect, Paint()..color = const Color(0xFF1B4D3C));
      tp.paint(canvas, Offset(bx + 8, 2 + (22 - tp.height) / 2));
    }
  }

  void _dashed(Canvas canvas, Offset a, Offset b, Paint paint) {
    const dash = 7.0;
    const gap = 5.0;
    final total = (b - a).distance;
    if (total == 0) return;
    final dir = (b - a) / total;
    var d = 0.0;
    while (d < total) {
      final end = d + dash > total ? total : d + dash;
      canvas.drawLine(a + dir * d, a + dir * end, paint);
      d += dash + gap;
    }
  }

  void _text(
    Canvas canvas,
    String text,
    Offset at,
    TextStyle style, {
    bool alignRight = false,
    bool centerX = false,
    bool centerY = false,
  }) {
    final tp = TextPainter(
      text: TextSpan(text: text, style: style),
      textDirection: TextDirection.ltr,
    )..layout();
    var dx = at.dx;
    var dy = at.dy;
    if (alignRight) dx -= tp.width;
    if (centerX) dx -= tp.width / 2;
    if (centerY) dy -= tp.height / 2;
    tp.paint(canvas, Offset(dx, dy));
  }

  @override
  bool shouldRepaint(covariant _ChartPainter old) =>
      old.hover != hover ||
      old.points != points ||
      old.slope != slope ||
      old.intercept != intercept ||
      old.color != color;
}
