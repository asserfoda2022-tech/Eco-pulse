import 'package:flutter/material.dart';
import 'package:project_1/models/community_post.dart';
import 'package:project_1/data/governorate_data.dart';
import 'package:project_1/theme/app_colors.dart';
import 'package:project_1/theme/app_language.dart';
import 'package:project_1/theme/app_text_styles.dart';
import 'package:project_1/widgets/custom_card.dart';

class PostCard extends StatelessWidget {
  final CommunityPost post;
  const PostCard({super.key, required this.post});

  String _ago(BuildContext context) {
    final t = post.createdAt;
    if (t == null) return context.tr('Just now', 'الآن');
    final d = DateTime.now().difference(t);
    if (d.inMinutes < 1) return context.tr('Just now', 'الآن');
    if (d.inMinutes < 60) {
      return context.tr('${d.inMinutes} min ago', 'منذ ${d.inMinutes} دقيقة');
    }
    if (d.inHours < 24) {
      return context.tr('${d.inHours} h ago', 'منذ ${d.inHours} ساعة');
    }
    return context.tr('${d.inDays} d ago', 'منذ ${d.inDays} يوم');
  }

  @override
  Widget build(BuildContext context) {
    final isAr = context.isAr;
    final gov = GovernorateData.byId(post.governorateId);
    final type = PhenomenonType.byId(post.phenomenonId);
    final author = post.authorName.isEmpty
        ? context.tr('EcoPulse member', 'عضو في EcoPulse')
        : post.authorName;

    return GlassCard(
      margin: const EdgeInsets.fromLTRB(20, 0, 20, 12),
      padding: EdgeInsets.zero,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (post.imageUrl != null)
            ClipRRect(
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(20)),
              child: Image.network(
                post.imageUrl!,
                height: 200,
                width: double.infinity,
                fit: BoxFit.cover,
                loadingBuilder: (_, child, progress) => progress == null
                    ? child
                    : const SizedBox(
                        height: 200,
                        child: Center(
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: AppColors.primary),
                        ),
                      ),
                errorBuilder: (_, __, ___) => const SizedBox(
                  height: 120,
                  child: Center(
                    child: Icon(Icons.broken_image_outlined,
                        color: AppColors.textMuted),
                  ),
                ),
              ),
            ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _Tag(icon: type.icon, text: type.name(isAr)),
                    _Tag(
                      icon: Icons.location_on_outlined,
                      text: gov.name(isAr),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Text(post.description, style: AppTextStyles.body),
                const SizedBox(height: 12),
                Row(
                  children: [
                    const Icon(Icons.person_outline_rounded,
                        size: 16, color: AppColors.textMuted),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        author,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: AppTextStyles.caption,
                      ),
                    ),
                    Text(_ago(context), style: AppTextStyles.caption),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Tag extends StatelessWidget {
  final IconData icon;
  final String text;
  const _Tag({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: AppColors.primary.withOpacity(0.14),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 15, color: AppColors.primary),
          const SizedBox(width: 6),
          Text(
            text,
            style: AppTextStyles.caption.copyWith(color: AppColors.primary),
          ),
        ],
      ),
    );
  }
}
